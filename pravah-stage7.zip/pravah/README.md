# Pravah: APFC exam prep (Stage 1: auth and layout)

1. Create a project at supabase.com, then run `supabase/schema.sql` in the SQL editor.
2. Auth > Providers: enable Email. For Google, add your Google OAuth client ID and secret.
3. Auth > URL Configuration: Site URL = http://localhost:3000, add redirect URL http://localhost:3000/auth/callback
4. `cp .env.example .env.local` and fill the two Supabase values.
5. `npm install` then `npm run dev`, open http://localhost:3000
6. Deploy: push to GitHub, import in Vercel, add the same env vars, then add your Vercel URL to Supabase redirect URLs.
Rename the brand in `src/lib/brand.ts`.

## Stage 5 notes
- Needs SUPABASE_SERVICE_ROLE_KEY and ANTHROPIC_API_KEY (questions are generated server-side and stored in the shared bank).
- Import previous year questions: Supabase > Table editor > pyq > Import CSV. Columns: year, topic_id (e.g. labour-8, see supabase/seed_topics.sql), stem, options (JSON array of 4 strings), answer (0 to 3), explanation. See supabase/pyq_sample.csv.
- Marking scheme and mock sizes: src/lib/exam.ts.

## Stage 7 notes
- Run supabase/stage7.sql.
- Current affairs uses the AI web-search tool, so ANTHROPIC_API_KEY must have web search enabled. The weekly summary can take about a minute; on Vercel Hobby the function limit may cut it short (Pro plan or a longer maxDuration fixes this).
- Payments: add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET (use test keys first). Prices are in src/lib/billing.ts. Pro access is granted after the payment is verified server-side. Also set up a Razorpay webhook for payment.captured before launch, so a student who closes the browser mid-payment still gets Pro.
