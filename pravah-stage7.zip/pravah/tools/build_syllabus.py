# Source of truth for the syllabus tree. Run: python3 tools/build_syllabus.py
# Writes src/lib/syllabus-data.json and supabase/seed_topics.sql
import json
S = {
"english": {
 "Grammar basics": "Parts of speech|Sentence structure|Subject-verb agreement|Nouns and pronouns",
 "Verbs and tenses": "Verbs, tenses and modals|Active and passive voice",
 "Connectors and modifiers": "Prepositions, conjunctions, articles|Adjectives, adverbs, determiners",
 "Vocabulary": "Synonyms and antonyms|Idioms and phrases|One word substitution",
 "Reading and ordering": "Reading comprehension|Para jumbles"},
"culture": {
 "Decline of the Mughals and regional powers": "Reasons for disintegration|Later Mughals|Emergence of regional powers",
 "Advent of Europeans": "Portuguese|Dutch|English|Danes|French",
 "Rise of the British": "Anglo-French struggle|Conquest of Bengal, Mysore, Marathas|Sindh, Punjab, Awadh|Administrative, police, revenue systems",
 "Early reforms under British rule": "Civil services, police, judiciary, army|Press, communication, education|Railways",
 "Revolt of 1857": "Causes|Spread and suppression|Failure and nature|Consequences",
 "Rise of nationalism and the INC": "Reasons for nationalism|Pre-Congress associations|Foundation of INC|Moderate phase|Indian Councils Act 1892",
 "Swadeshi and extremism": "Extremists|Swadeshi movement|Morley-Minto reforms",
 "Events 1908-1918": "First revolutionary phase|Delhi Durbars|World War I and nationalism|Gandhi's entry|Congress sessions",
 "Events 1919-1929": "GoI Act 1919|Rowlatt Act|Non-cooperation and Khilafat|Swarajists|Left movement|Simon Commission and Nehru Report",
 "Events 1929-1939": "Civil Disobedience Movement|Karachi session|Round Table Conferences|Communal Award and Poona Pact|GoI Act 1935|1937 elections",
 "Events 1940-1947": "Wardha resolution|August Offer|Cripps Mission|Quit India|INA and RIN mutiny|Run-up to independence",
 "Socio-religious reform movements": "Eastern India|Western India|North India|Reform movements of other religions",
 "Other modern history": "Anti-colonial rebellions|Tribal uprisings|Peasant movements",
 "Ancient and medieval history": "Indus Valley|Vedic age|Mahajanapadas|Mauryan and post-Mauryan|Gupta age and Harsha|Delhi Sultanate|Mughal rule",
 "Religion and philosophy": "Schools of Indian philosophy|Buddhism and Jainism|Bhakti and Sufi movements|Important saints",
 "Art and architecture": "Sculpture|Rock-cut and cave architecture|Temple architecture|Indo-Islamic architecture|UNESCO World Heritage sites",
 "Music, dance and painting": "Hindustani and Carnatic music|Folk music and theatre|Classical and folk dances|Painting styles",
 "Languages, literature and festivals": "Language families|Scripts|Literature|Fairs and festivals"},
"current": {
 "Government schemes": "Labour and employment schemes|Social welfare schemes|Flagship schemes",
 "Reports and indices": "National reports|International organisation reports|Rankings and indices",
 "Awards, appointments and persons": "Awards and milestones|Appointments|Persons in the news",
 "Sports, defence and places": "Sports events|Defence exercises|Places in the news|First in the news",
 "Environment, books and days": "Environment|Books and authors|Important days|Fairs and festivals"},
"development": {
 "Concept of development": "Meaning|Pillars|Processes",
 "Human development": "Concept|Human Development Index"},
"polity": {
 "Constitutional framework": "Historical background|Making of the Constitution|Features|Preamble|Amendments|Basic structure",
 "Union and citizenship": "Making of the Union|Citizenship",
 "Rights and duties": "Fundamental rights|Directive Principles|Fundamental duties",
 "Centre-state relations": "Legislative relations|Administrative relations|Financial relations|Inter-state councils|Emergency provisions",
 "Union executive": "President|Vice President|Prime Minister|Council of Ministers|Cabinet committees",
 "State executive": "Governor|Chief Minister|State Council of Ministers",
 "Parliament": "Composition|Presiding officers|Legislative procedure|Budget|Privileges|Committees",
 "State legislature": "Composition|Presiding officers|Proceedings|Election system",
 "Judiciary": "Supreme Court|High Courts|Subordinate courts|NALSA|Tribunals",
 "Constitutional and other bodies": "Constitutional bodies|Non-constitutional bodies|Quasi-judicial bodies|Regulatory bodies",
 "Local government": "Panchayati Raj|Municipalities",
 "Miscellaneous polity": "Union Territories|Scheduled and tribal areas|Special provisions for states|Electoral reforms"},
"economy": {
 "Demand and supply": "Micro vs macro|Demand|Supply|Equilibrium",
 "Elasticity of demand": "Price elasticity|Cross elasticity|Income elasticity",
 "Measurement of growth": "Circular flow of income|GDP|Macroeconomic identities|Market structures",
 "Poverty and employment": "Poverty measurement|Poverty-related SDGs|Types of unemployment|Employment status in India",
 "Economic history and planning": "Features of the Indian economy|Planning before and after independence|Economic reforms|NITI Aayog",
 "Monetary policy": "Instruments|Types|Financial institutions",
 "Inflation": "Causes and effects|Measurement|Control measures|Inflation targeting",
 "Fiscal policy": "Budget components|Deficit measures|Public debt|GST",
 "Regional economic cooperation": "SAARC, ASEAN, BIMSTEC|RCEP, CPTPP|BRICS, SCO, IORA, APEC|India's FTAs",
 "International economic institutions": "World Bank|IMF|WTO",
 "Balance of payments": "Balance of payments|Exchange rate|Exchange rate management",
 "Industrial and labour policy": "Evolution of industrial policy|Disinvestment|MSMEs|SEZs and industrial corridors|Labour policy",
 "Finance Commission": "Composition|Roles and functions|14th and 15th Finance Commissions"},
"accounting": {
 "Introduction to accounting": "Branches|Objectives|Accounting process",
 "Theory base": "Principles and conventions|Terminology",
 "Recording transactions": "Source documents|Accounting equation|Journal, ledger, cash book|Rules of debit and credit",
 "Trial balance": "Types of errors|Preparing a trial balance|Suspense account",
 "Bills of exchange": "Parties|Discounting|Promissory note",
 "Accounting standards": "Share capital|Inventory and investments|Bonus shares and buyback",
 "Final accounts": "Trading account|Profit and loss account|Balance sheet",
 "Ratio analysis and cash flow": "Types of ratios|Cash flow statement"},
"auditing": {
 "Concepts of auditing": "Nature, objective, scope|Classification of audit",
 "Audit planning and risk": "Strategy, planning, programme|Risk assessment and internal control",
 "Vouching and verification": "Vouching|Verification of assets and liabilities",
 "Company audit": "Company auditor|Auditor's report",
 "Audit of different entities": "Companies|Not-for-profit and other entities"},
"labour": {
 "Industrial relations basics": "Overview|Indian labour force|Trade unions",
 "Bargaining and discipline": "Collective bargaining|Industrial discipline|Grievance procedure",
 "Industrial disputes": "Conflicts and disputes|Settlement of disputes",
 "Welfare and wages": "Labour welfare|Wages",
 "Participation and safety": "Workers' participation in management|Health and safety|International industrial relations",
 "Code on Wages, 2019": "Wages and bonus provisions|Minimum wages|Inspector-cum-facilitator",
 "Industrial Relations Code, 2020": "Trade unions|Standing orders|Strikes, lay-off, retrenchment",
 "Code on Social Security, 2020": "EPF, ESI, gratuity provisions|Gig and platform workers|Social security funds",
 "OSH and Working Conditions Code, 2020": "Safety and health duties|Working conditions|Welfare facilities"},
"insurance": {
 "Introduction to insurance": "Concept and definition|Risk and insurance|Parties|Terminology",
 "Principles of insurance": "Utmost good faith|Insurable interest|Proximate cause|Subrogation|Indemnity|Contribution|Loss minimisation",
 "Life insurance": "Term insurance|ULIP|Pension plans|Money-back policy",
 "General insurance": "Motor|Home|Fire|Other types",
 "Insurance and social security": "Social security insurance schemes|Social vs private insurance|Emerging concepts"},
"computer": {
 "Introduction to computers": "Definition and parts|History and generations|Types|Shortcuts and full forms",
 "Computer organisation": "Organisation|Data processing cycle|Instruction cycle",
 "Hardware and software": "Input and output devices|Motherboard|Types of software",
 "Memory": "Memory hierarchy|Memory management|Memory measurement",
 "Operating systems": "Functions|Types|MS-DOS and Windows",
 "Computer networks": "Components|Types and architecture|Protocols and topology|Internet"},
"science": {
 "Physics": "Units and measurements|Kinematics|Newton's laws|Electricity|Pressure|Light|Circular and simple harmonic motion",
 "Chemistry": "Physical and chemical changes|Elements, compounds, mixtures|Atoms and molecules|Acids and bases|Metals and non-metals|Energy sources",
 "Biology": "Food components|Health and diseases|Cells and tissues|Organ systems",
 "Space technology": "Satellites and orbits|Indian space programme|Space agencies|Applications",
 "Important technologies": "Nuclear|Biotechnology|ICT|Nanotechnology"},
"maths": {
 "Number work": "Simplification|LCM and HCF|Number series",
 "Percentages and ratios": "Percentage|Ratio and proportion|Mixture and allegation|Profit and loss",
 "Interest and averages": "Simple and compound interest|Average",
 "Time, work and distance": "Time and work|Pipes and cisterns|Time and distance|Boats and streams",
 "Geometry and mensuration": "Mensuration 2D and 3D|Basic geometry|Height and distance|Trigonometry",
 "Data and probability": "Data interpretation|Probability|Logarithm"},
"statistics": {
 "Basics of statistics": "Core concepts|Types of data",
 "Central tendency": "Mean|Median|Mode",
 "Dispersion": "Standard deviation|Applications of dispersion",
 "Sampling": "Sampling methods"},
"reasoning": {
 "Series and coding": "Alphabetical and alphanumeric series|Letter series|Coding and decoding",
 "Relations and direction": "Blood relation|Direction sense|Ranking and order",
 "Logic": "Syllogism|Analogy|Venn diagram",
 "Clock, calendar, dice": "Clock|Calendar|Dice",
 "Figures": "Counting figures|Cube and cuboid"},
"social": {
 "Social security schemes": "Types of retirement schemes|National Pension System|Atal Pension Yojana",
 "Employees' Compensation Act, 1923": "Compensation provisions|Employer liability",
 "Employees' State Insurance Act, 1948": "Coverage|Benefits|ESI Corporation",
 "EPF and Miscellaneous Provisions Act, 1952": "EPF, EPS, EDLI schemes|Coverage and contributions|Enforcement and penalties",
 "Maternity Benefit Act, 1961": "Eligibility|Benefits and leave",
 "Payment of Gratuity Act, 1972": "Eligibility|Calculation and limits",
 "Unorganised Workers' Social Security Act, 2008": "Schemes|Welfare boards"}}
out, sql = {}, []
q = lambda s: "'" + s.replace("'", "''") + "'"
for sid, topics in S.items():
    out[sid] = []
    for i, (name, subs) in enumerate(topics.items(), 1):
        tid, sl = f"{sid}-{i}", subs.split("|")
        out[sid].append({"id": tid, "name": name, "subs": sl})
        arr = "array[" + ",".join(q(x) for x in sl) + "]"
        sql.append(f"({q(tid)},{q(sid)},{q(name)},{i},{arr})")
json.dump(out, open("src/lib/syllabus-data.json", "w"), ensure_ascii=False, indent=1)
open("supabase/seed_topics.sql", "w").write("insert into topics (id, subject_id, name, sort, subtopics) values\n" + ",\n".join(sql) + "\non conflict (id) do update set name=excluded.name, subtopics=excluded.subtopics;\n")
print(sum(len(v) for v in out.values()), "topics")
