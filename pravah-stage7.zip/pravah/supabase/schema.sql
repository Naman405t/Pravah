-- Run in Supabase SQL editor. "users" = Supabase auth.users; app data lives in profiles.
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text, target_exam text default 'APFC', attempt_year int, daily_hours numeric default 4,
  weak_subjects text[] default '{}', language text default 'en', onboarded boolean default false,
  created_at timestamptz default now()
);
create table study_plans (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
  exam_date date, daily_hours numeric, plan jsonb not null, created_at timestamptz default now());
create table chats (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
  title text, mode text default 'solver', created_at timestamptz default now());
create table messages (id uuid primary key default gen_random_uuid(), chat_id uuid references chats on delete cascade,
  user_id uuid references auth.users on delete cascade, role text not null, content text not null, created_at timestamptz default now());
create table topics (id text primary key, subject_id text not null, parent_id text, name text not null, sort int default 0);
create table notes (id uuid primary key default gen_random_uuid(), topic_id text references topics, content_md text, created_at timestamptz default now());
create table questions (id uuid primary key default gen_random_uuid(), topic_id text references topics, stem text not null, options jsonb not null,
  answer int not null, explanation text, difficulty text default 'medium', source text default 'ai', created_at timestamptz default now());
create table pyq (id uuid primary key default gen_random_uuid(), year int, topic_id text references topics, stem text not null,
  options jsonb not null, answer int not null, explanation text);
create table mock_tests (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
  title text, question_ids uuid[], duration_min int, created_at timestamptz default now());
create table attempts (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
  question_id uuid references questions, mock_id uuid references mock_tests, chosen int, correct boolean, seconds int, created_at timestamptz default now());
create table flashcards (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
  front text, back text, due_at timestamptz default now(), created_at timestamptz default now());
create table bookmarks (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
  question_id uuid references questions, created_at timestamptz default now());
create table subscriptions (user_id uuid primary key references auth.users on delete cascade, plan text default 'free',
  razorpay_id text, valid_until timestamptz);

-- Row level security: users only see their own rows
do $$ declare t text; begin
  foreach t in array array['profiles','study_plans','chats','messages','mock_tests','attempts','flashcards','bookmarks','subscriptions'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "own rows" on %I for all using (auth.uid() = %s) with check (auth.uid() = %s)',
      t, case when t='profiles' then 'id' else 'user_id' end, case when t='profiles' then 'id' else 'user_id' end);
  end loop;
end $$;
-- Shared content: readable by any signed-in user
do $$ declare t text; begin
  foreach t in array array['topics','notes','questions','pyq'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "read all" on %I for select using (auth.role() = ''authenticated'')', t);
  end loop;
end $$;
