-- Run BEFORE seed_topics.sql
alter table topics add column if not exists subtopics text[] default '{}';
create unique index if not exists notes_topic_uidx on notes(topic_id);
create table if not exists topic_progress (
  user_id uuid references auth.users on delete cascade, topic_id text references topics on delete cascade,
  created_at timestamptz default now(), primary key (user_id, topic_id));
alter table topic_progress enable row level security;
create policy "own rows" on topic_progress for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
