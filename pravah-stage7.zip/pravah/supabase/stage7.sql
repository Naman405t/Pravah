create table if not exists current_affairs (
  id uuid primary key default gen_random_uuid(), week_start date unique not null,
  content_md text not null, question_ids uuid[] default '{}', created_at timestamptz default now());
alter table current_affairs enable row level security;
create policy "read all" on current_affairs for select using (auth.role() = 'authenticated');
alter table flashcards add column if not exists interval_days int default 0;
create unique index if not exists bookmarks_uidx on bookmarks(user_id, question_id);
