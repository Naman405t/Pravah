import { createClient } from "@/lib/supabase/server";

const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const body = await req.json().catch(() => null);
  const list: { questionId: string; chosen: number | null; seconds: number }[] = Array.isArray(body?.attempts) ? body.attempts.slice(0, 100) : [];
  if (!list.length) return json({ error: "Nothing to grade." }, 400);
  const mockId: string | null = body?.mockId ?? null;

  const { data: qs } = await sb.from("questions").select("id,answer,explanation").in("id", list.map((a) => a.questionId));
  const byId = new Map((qs ?? []).map((q) => [q.id, q]));
  const results = list.filter((a) => byId.has(a.questionId)).map((a) => {
    const q = byId.get(a.questionId)!;
    const chosen = Number.isInteger(a.chosen) && a.chosen! >= 0 && a.chosen! < 4 ? a.chosen! : null;
    return { questionId: a.questionId, chosen, correct: chosen === q.answer, answer: q.answer as number, explanation: (q.explanation ?? "") as string, seconds: Math.max(0, Math.min(3600, Math.round(Number(a.seconds) || 0))) };
  });
  await sb.from("attempts").insert(results.map((r) => ({ user_id: user.id, question_id: r.questionId, mock_id: mockId, chosen: r.chosen, correct: r.correct, seconds: r.seconds })));
  return json({ results });
}
