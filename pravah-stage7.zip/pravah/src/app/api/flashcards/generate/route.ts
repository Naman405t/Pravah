import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const maxDuration = 60;
const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const body = await req.json().catch(() => ({}));
  let source = typeof body.text === "string" ? body.text : "";
  if (typeof body.topicId === "string") {
    const { data } = await sb.from("notes").select("content_md").eq("topic_id", body.topicId).maybeSingle();
    source = data?.content_md ?? "";
  }
  if (source.length < 40) return json({ error: "Not enough content to make cards from." }, 400);
  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const r = await client.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 1500,
      system: "You write revision flashcards. Output only a valid JSON array, no commentary, no code fences.",
      messages: [{ role: "user", content: `Make up to 8 short flashcards from this text for a UPSC EPFO APFC aspirant. Each card tests one fact. Use only facts in the text. Format: [{"front":"question","back":"short answer"}]\n\nTEXT:\n${source.slice(0, 6000)}` }],
    });
    const t = r.content.map((b) => (b.type === "text" ? b.text : "")).join("").replace(/```json|```/g, "").trim();
    const arr = JSON.parse(t.slice(t.indexOf("["), t.lastIndexOf("]") + 1));
    const rows = (Array.isArray(arr) ? arr : []).filter((c) => typeof c?.front === "string" && typeof c?.back === "string").slice(0, 8)
      .map((c) => ({ user_id: user.id, front: c.front.slice(0, 400), back: c.back.slice(0, 600) }));
    if (!rows.length) return json({ error: "No cards were made. Please retry." }, 502);
    const { error } = await sb.from("flashcards").insert(rows);
    if (error) return json({ error: error.message }, 500);
    return json({ count: rows.length });
  } catch { return json({ error: "Could not make cards right now. Please retry." }, 502); }
}
