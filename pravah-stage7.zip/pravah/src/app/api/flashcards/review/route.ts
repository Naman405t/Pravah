import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { id, good } = await req.json().catch(() => ({}));
  if (!user || typeof id !== "string") return new Response("{}", { status: 400 });
  const { data: c } = await sb.from("flashcards").select("interval_days").eq("id", id).eq("user_id", user.id).maybeSingle();
  if (!c) return new Response("{}", { status: 404 });
  const next = good ? Math.min(60, Math.max(1, (c.interval_days ?? 0) * 2)) : 0;
  const due = new Date(Date.now() + (good ? next * 864e5 : 10 * 60e3)).toISOString();
  await sb.from("flashcards").update({ interval_days: next, due_at: due }).eq("id", id).eq("user_id", user.id);
  return new Response("{}", { status: 200 });
}
