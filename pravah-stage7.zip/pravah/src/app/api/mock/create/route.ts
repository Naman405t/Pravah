import { createClient } from "@/lib/supabase/server";
import { generateQuestions, shuffle, type Q } from "@/lib/generate";
import { SUBJECTS } from "@/lib/syllabus";
import { TREE } from "@/lib/topics";
import { MOCKS } from "@/lib/exam";
import { practiceBlocked } from "@/lib/limits";

export const runtime = "nodejs";
export const maxDuration = 60;
const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const { kind } = await req.json().catch(() => ({}));
  const cfg = MOCKS[kind as keyof typeof MOCKS];
  if (!cfg) return json({ error: "Invalid mock type." }, 400);
  const blocked = await practiceBlocked(sb, user.id);
  if (blocked) return json({ error: blocked }, 429);

  // split questions across subjects by weight
  const total = SUBJECTS.reduce((a, s) => a + s.weight, 0);
  const need = SUBJECTS.map((s) => ({ id: s.id, n: Math.max(1, Math.round((s.weight / total) * cfg.questions)) }));
  const { data: done } = await sb.from("attempts").select("question_id").eq("user_id", user.id).limit(3000);
  const seen = new Set((done ?? []).map((d) => d.question_id));

  const parts = await Promise.all(need.map(async ({ id, n }) => {
    const { data: bank } = await sb.from("questions").select("id,stem,options").like("topic_id", `${id}-%`).limit(60);
    let got: Q[] = shuffle((bank ?? []).filter((q) => !seen.has(q.id)) as Q[]).slice(0, n);
    if (got.length < n) {
      try {
        const topic = shuffle(TREE[id])[0];
        got = [...got, ...(await generateQuestions(topic.id, "medium", n - got.length))];
      } catch {}
    }
    return got;
  }));
  const questions = shuffle(parts.flat()).slice(0, cfg.questions);
  if (questions.length < 10) return json({ error: "Could not build the mock. Check that SUPABASE_SERVICE_ROLE_KEY and ANTHROPIC_API_KEY are set, then retry." }, 502);

  const { data: mock, error } = await sb.from("mock_tests").insert({
    user_id: user.id, title: `${cfg.label} (${questions.length} questions)`, question_ids: questions.map((q) => q.id),
    duration_min: Math.ceil((cfg.minutes * questions.length) / cfg.questions),
  }).select("id").single();
  if (error) return json({ error: error.message }, 500);
  return json({ id: mock.id });
}
