import Anthropic from "@anthropic-ai/sdk";
import { createClient as createAdmin } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import { findTopic } from "@/lib/topics";
import { buildSystem, buildNotesPrompt } from "@/lib/prompts";

export const runtime = "nodejs";
export const maxDuration = 60;
const json = (body: object, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

export async function GET(req: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const found = findTopic(new URL(req.url).searchParams.get("topic") ?? "");
  if (!found) return json({ error: "Unknown topic." }, 404);
  const { topic, subject } = found;

  const { data: cached } = await supabase.from("notes").select("content_md").eq("topic_id", topic.id).maybeSingle();
  if (cached?.content_md) return json({ content: cached.content_md });
  if (!process.env.ANTHROPIC_API_KEY) return json({ error: "Server is missing ANTHROPIC_API_KEY." }, 500);

  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const r = await client.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 2200,
      system: buildSystem("exam"),
      messages: [{ role: "user", content: buildNotesPrompt(subject.name, topic.name, topic.subs) }],
    });
    const content = r.content.map((b) => (b.type === "text" ? b.text : "")).join("").trim();
    if (!content) return json({ error: "No notes were generated. Please retry." }, 502);
    if (process.env.SUPABASE_SERVICE_ROLE_KEY) {
      const admin = createAdmin(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY);
      await admin.from("notes").upsert({ topic_id: topic.id, content_md: content }, { onConflict: "topic_id" });
    }
    return json({ content });
  } catch {
    return json({ error: "Could not generate notes right now. Please retry." }, 502);
  }
}
