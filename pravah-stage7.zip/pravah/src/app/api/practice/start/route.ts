import { createClient } from "@/lib/supabase/server";
import { generateQuestions, shuffle, type Q } from "@/lib/generate";
import { findTopic } from "@/lib/topics";
import { practiceBlocked } from "@/lib/limits";

export const runtime = "nodejs";
export const maxDuration = 60;
const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const { topicId, difficulty, count } = await req.json().catch(() => ({}));
  if (!findTopic(topicId) || !["easy", "medium", "hard"].includes(difficulty) || ![5, 10].includes(count)) return json({ error: "Invalid request." }, 400);
  const blocked = await practiceBlocked(sb, user.id);
  if (blocked) return json({ error: blocked }, 429);

  const { data: done } = await sb.from("attempts").select("question_id").eq("user_id", user.id).limit(3000);
  const seen = new Set((done ?? []).map((d) => d.question_id));
  const { data: bank } = await sb.from("questions").select("id,stem,options").eq("topic_id", topicId).eq("difficulty", difficulty).limit(80);
  let picked: Q[] = shuffle((bank ?? []).filter((q) => !seen.has(q.id)) as Q[]).slice(0, count);
  try {
    if (picked.length < count) picked = [...picked, ...(await generateQuestions(topicId, difficulty, count - picked.length))];
  } catch (e) {
    if (!picked.length) return json({ error: e instanceof Error ? e.message : "Could not create questions." }, 502);
  }
  return json({ questions: picked });
}
