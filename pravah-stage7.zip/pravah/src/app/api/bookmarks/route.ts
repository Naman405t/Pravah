import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { questionId, saved } = await req.json().catch(() => ({}));
  if (!user || typeof questionId !== "string") return new Response("{}", { status: 400 });
  const { error } = saved
    ? await sb.from("bookmarks").upsert({ user_id: user.id, question_id: questionId }, { onConflict: "user_id,question_id" })
    : await sb.from("bookmarks").delete().eq("user_id", user.id).eq("question_id", questionId);
  return new Response("{}", { status: error ? 500 : 200 });
}
