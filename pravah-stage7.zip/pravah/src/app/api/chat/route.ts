import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";
import { buildSystem, MODES, type Mode } from "@/lib/prompts";

export const runtime = "nodejs";
export const maxDuration = 60;

const FREE_DAILY_LIMIT = 20;
const json = (error: string, status: number) =>
  new Response(JSON.stringify({ error }), { status, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return json("Please sign in again.", 401);
  if (!process.env.ANTHROPIC_API_KEY) return json("Server is missing ANTHROPIC_API_KEY.", 500);

  const body = await req.json().catch(() => null);
  const message = typeof body?.message === "string" ? body.message.trim() : "";
  const mode: Mode = MODES.includes(body?.mode) ? body.mode : "solver";
  if (!message || message.length > 4000) return json("Message must be 1 to 4000 characters.", 400);

  // Free tier: 20 student messages per day unless a paid plan exists
  const since = new Date(); since.setUTCHours(0, 0, 0, 0);
  const [{ count }, { data: sub }] = await Promise.all([
    supabase.from("messages").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("role", "user").gte("created_at", since.toISOString()),
    supabase.from("subscriptions").select("plan,valid_until").eq("user_id", user.id).maybeSingle(),
  ]);
  const pro = sub?.plan === "pro" && (!sub.valid_until || new Date(sub.valid_until) > new Date());
  if (!pro && (count ?? 0) >= FREE_DAILY_LIMIT) return json(`You have used today's ${FREE_DAILY_LIMIT} free messages. Come back tomorrow or upgrade.`, 429);

  let chatId: string | null = body?.chatId ?? null;
  if (chatId) {
    const { data } = await supabase.from("chats").select("id").eq("id", chatId).maybeSingle();
    if (!data) return json("Chat not found.", 404);
  } else {
    const { data, error } = await supabase.from("chats").insert({ user_id: user.id, title: message.slice(0, 60), mode }).select("id").single();
    if (error) return json(error.message, 500);
    chatId = data.id;
  }

  await supabase.from("messages").insert({ chat_id: chatId, user_id: user.id, role: "user", content: message });
  const { data: rows } = await supabase.from("messages").select("role,content").eq("chat_id", chatId).order("created_at", { ascending: false }).limit(20);
  const history = (rows ?? []).reverse().map((r) => ({ role: r.role as "user" | "assistant", content: r.content }));

  const { data: prof } = await supabase.from("profiles").select("language").eq("id", user.id).maybeSingle();
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let full = "";
      try {
        const s = client.messages.stream({
          model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
          max_tokens: 1500,
          system: buildSystem(mode, prof?.language === "hi" ? "hi" : "en"),
          messages: history,
        });
        for await (const ev of s) {
          if (ev.type === "content_block_delta" && ev.delta.type === "text_delta") {
            full += ev.delta.text;
            controller.enqueue(enc.encode(ev.delta.text));
          }
        }
        if (full) await supabase.from("messages").insert({ chat_id: chatId, user_id: user.id, role: "assistant", content: full });
      } catch {
        controller.enqueue(enc.encode("\n\nThe tutor could not finish this answer. Please send your message again."));
      }
      controller.close();
    },
  });
  return new Response(stream, { headers: { "Content-Type": "text/plain; charset=utf-8", "x-chat-id": chatId!, "Cache-Control": "no-store" } });
}
