import { createClient } from "@/lib/supabase/server";
import { PLANS, rzpAuth } from "@/lib/billing";

const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return json({ error: "Payments are not configured yet." }, 500);
  const { plan: id } = await req.json().catch(() => ({}));
  const plan = PLANS.find((p) => p.id === id);
  if (!plan) return json({ error: "Unknown plan." }, 400);
  const r = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST", headers: { Authorization: rzpAuth(), "Content-Type": "application/json" },
    body: JSON.stringify({ amount: plan.price * 100, currency: "INR", receipt: `u${user.id.slice(0, 8)}_${Date.now()}`, notes: { user_id: user.id, plan: plan.id } }),
  });
  const o = await r.json().catch(() => ({}));
  if (!r.ok) return json({ error: "Could not start the payment. Please retry." }, 502);
  return json({ orderId: o.id, amount: o.amount, keyId: process.env.RAZORPAY_KEY_ID, name: plan.name });
}
