import { createHmac, timingSafeEqual } from "crypto";
import { createClient } from "@/lib/supabase/server";
import { getAdmin } from "@/lib/generate";
import { PLANS, rzpAuth } from "@/lib/billing";

const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const { orderId, paymentId, signature } = await req.json().catch(() => ({}));
  if (![orderId, paymentId, signature].every((x) => typeof x === "string")) return json({ error: "Invalid payment data." }, 400);

  const expected = createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(expected), b = Buffer.from(signature);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return json({ error: "Payment signature check failed." }, 400);

  // confirm with Razorpay that this order is paid and belongs to this user
  const r = await fetch(`https://api.razorpay.com/v1/orders/${orderId}`, { headers: { Authorization: rzpAuth() } });
  const order = await r.json().catch(() => ({}));
  const plan = PLANS.find((p) => p.id === order?.notes?.plan);
  if (!r.ok || order.status !== "paid" || order.notes?.user_id !== user.id || !plan) return json({ error: "Could not confirm this payment." }, 400);

  const admin = getAdmin();
  if (!admin) return json({ error: "Server is missing SUPABASE_SERVICE_ROLE_KEY." }, 500);
  const { data: sub } = await admin.from("subscriptions").select("razorpay_id,valid_until").eq("user_id", user.id).maybeSingle();
  if (sub?.razorpay_id === paymentId) return json({ ok: true });
  const start = sub?.valid_until && new Date(sub.valid_until) > new Date() ? new Date(sub.valid_until) : new Date();
  const valid = new Date(start.getTime() + plan.days * 864e5).toISOString();
  await admin.from("subscriptions").upsert({ user_id: user.id, plan: "pro", razorpay_id: paymentId, valid_until: valid });
  return json({ ok: true, valid_until: valid });
}
