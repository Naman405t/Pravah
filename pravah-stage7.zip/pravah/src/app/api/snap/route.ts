import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";
import { buildSnapSystem } from "@/lib/prompts";

export const runtime = "nodejs";
export const maxDuration = 60;

const FREE_DAILY_LIMIT = 20; // shared with tutor messages
const TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const json = (error: string, status: number) =>
  new Response(JSON.stringify({ error }), { status, headers: { "Content-Type": "application/json" } });

export async function POST(req: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return json("Please sign in again.", 401);
  if (!process.env.ANTHROPIC_API_KEY) return json("Server is missing ANTHROPIC_API_KEY.", 500);

  const form = await req.formData().catch(() => null);
  const file = form?.get("image");
  const note = String(form?.get("note") ?? "").slice(0, 500);
  if (!(file instanceof File)) return json("Please choose a photo.", 400);
  if (!TYPES.includes(file.type)) return json("Use a JPG, PNG, WebP or GIF photo.", 400);
  if (file.size > 5 * 1024 * 1024) return json("Photo is larger than 5 MB. Try a smaller one.", 400);

  const since = new Date(); since.setUTCHours(0, 0, 0, 0);
  const [{ count }, { data: sub }] = await Promise.all([
    supabase.from("messages").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("role", "user").gte("created_at", since.toISOString()),
    supabase.from("subscriptions").select("plan,valid_until").eq("user_id", user.id).maybeSingle(),
  ]);
  const pro = sub?.plan === "pro" && (!sub.valid_until || new Date(sub.valid_until) > new Date());
  if (!pro && (count ?? 0) >= FREE_DAILY_LIMIT) return json(`You have used today's ${FREE_DAILY_LIMIT} free messages. Come back tomorrow or upgrade.`, 429);

  const data = Buffer.from(await file.arrayBuffer()).toString("base64");
  const { data: chat, error } = await supabase.from("chats").insert({ user_id: user.id, title: `Photo question${note ? `: ${note.slice(0, 40)}` : ""}`, mode: "solver" }).select("id").single();
  if (error) return json(error.message, 500);
  await supabase.from("messages").insert({ chat_id: chat.id, user_id: user.id, role: "user", content: `[Photo question]${note ? ` ${note}` : ""}` });

  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let full = "";
      try {
        const s = client.messages.stream({
          model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
          max_tokens: 1800,
          system: buildSnapSystem(),
          messages: [{ role: "user", content: [
            { type: "image", source: { type: "base64", media_type: file.type as "image/jpeg", data } },
            { type: "text", text: note || "Solve the question in this photo." },
          ] }],
        });
        for await (const ev of s) {
          if (ev.type === "content_block_delta" && ev.delta.type === "text_delta") {
            full += ev.delta.text;
            controller.enqueue(enc.encode(ev.delta.text));
          }
        }
        if (full) await supabase.from("messages").insert({ chat_id: chat.id, user_id: user.id, role: "assistant", content: full });
      } catch {
        controller.enqueue(enc.encode("\n\nCould not finish reading this photo. Please try again."));
      }
      controller.close();
    },
  });
  return new Response(stream, { headers: { "Content-Type": "text/plain; charset=utf-8", "x-chat-id": chat.id, "Cache-Control": "no-store" } });
}
