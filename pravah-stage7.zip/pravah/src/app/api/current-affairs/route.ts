import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";
import { getAdmin, questionsFromText } from "@/lib/generate";
import { weekStart } from "@/lib/week";

export const runtime = "nodejs";
export const maxDuration = 60;
const json = (b: object, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });

export async function POST() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: "Please sign in again." }, 401);
  const admin = getAdmin();
  if (!admin || !process.env.ANTHROPIC_API_KEY) return json({ error: "Server keys are missing (ANTHROPIC_API_KEY, SUPABASE_SERVICE_ROLE_KEY)." }, 500);
  const ws = weekStart();
  const { data: have } = await admin.from("current_affairs").select("id").eq("week_start", ws).maybeSingle();
  if (have) return json({ ok: true });

  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const r = await client.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 2500,
      tools: [{ type: "web_search_20250305", name: "web_search", max_uses: 5 }] as unknown as Anthropic.Tool[],
      messages: [{ role: "user", content: `Today is ${new Date().toISOString().slice(0, 10)}. Use web search to find the most important news from the last 7 days for a UPSC EPFO APFC aspirant: labour and employment, EPFO and EPF/ESI/social security, the four Labour Codes, economy (RBI, budget, inflation, trade), government schemes, key reports and appointments in India.
Write 8 to 10 items in Markdown. For each: a bold headline, two plain sentences, the date, and the source name. Only include what you found in search results; never invent. If reports conflict or are unclear, say so. Start directly with the items.` }],
    });
    const content = r.content.map((b) => (b.type === "text" ? b.text : "")).join("").trim();
    if (content.length < 200) return json({ error: "Could not find enough reliable news. Please retry later." }, 502);
    let ids: string[] = [];
    try { ids = (await questionsFromText("current-1", content, 5, "current_affairs")).map((q) => q.id); } catch {}
    await admin.from("current_affairs").upsert({ week_start: ws, content_md: content, question_ids: ids }, { onConflict: "week_start", ignoreDuplicates: true });
    return json({ ok: true });
  } catch {
    return json({ error: "Could not prepare this week's summary. Please retry." }, 502);
  }
}
