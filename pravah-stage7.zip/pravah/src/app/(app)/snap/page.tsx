import SnapSolve from "@/components/SnapSolve";

export default function Snap() {
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Snap and solve</h1>
      <p className="mb-6 mt-1 opacity-70">Photograph any question and get the answer, the steps, and the syllabus topic it belongs to.</p>
      <SnapSolve />
    </div>
  );
}
