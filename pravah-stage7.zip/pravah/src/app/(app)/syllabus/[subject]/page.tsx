import Link from "next/link";
import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { Check } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { TREE, subjectById } from "@/lib/topics";

export default async function SubjectPage({ params }: { params: { subject: string } }) {
  const subject = subjectById(params.subject);
  if (!subject) notFound();
  const topics = TREE[subject.id] ?? [];
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data } = await supabase.from("topic_progress").select("topic_id").eq("user_id", user!.id).like("topic_id", `${subject.id}-%`);
  const done = new Set((data ?? []).map((d) => d.topic_id));

  async function toggle(fd: FormData) {
    "use server";
    const sb = createClient();
    const { data: { user } } = await sb.auth.getUser();
    const id = String(fd.get("id"));
    if (!user || !topics.some((t) => t.id === id)) return;
    if (fd.get("done") === "1") await sb.from("topic_progress").delete().eq("user_id", user.id).eq("topic_id", id);
    else await sb.from("topic_progress").upsert({ user_id: user.id, topic_id: id });
    revalidatePath("/syllabus", "layout");
  }

  return (
    <div>
      <Link href="/syllabus" className="text-sm text-leaf underline">All subjects</Link>
      <h1 className="mb-1 mt-2 font-display text-3xl font-bold">{subject.name}</h1>
      <p className="mb-6 opacity-70">{done.size} of {topics.length} topics finished.</p>
      <ul className="space-y-3">
        {topics.map((t) => (
          <li key={t.id} className="flex items-start gap-3 rounded-2xl bg-white p-4 dark:bg-nightcard">
            <form action={toggle}>
              <input type="hidden" name="id" value={t.id} /><input type="hidden" name="done" value={done.has(t.id) ? "1" : "0"} />
              <button aria-label={done.has(t.id) ? `Mark ${t.name} as not finished` : `Mark ${t.name} as finished`}
                className={`mt-0.5 flex h-6 w-6 items-center justify-center rounded-full border-2 ${done.has(t.id) ? "border-leaf bg-leaf text-white" : "border-ink/30"}`}>
                {done.has(t.id) && <Check className="h-4 w-4" />}</button>
            </form>
            <Link href={`/syllabus/${subject.id}/${t.id}`} className="flex-1">
              <span className="font-medium">{t.name}</span>
              <span className="mt-0.5 block text-sm opacity-60">{t.subs.join(", ")}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
