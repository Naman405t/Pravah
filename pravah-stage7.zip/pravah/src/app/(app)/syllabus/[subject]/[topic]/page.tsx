import Link from "next/link";
import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { findTopic } from "@/lib/topics";
import Notes from "@/components/Notes";

export default async function TopicPage({ params }: { params: { subject: string; topic: string } }) {
  const found = findTopic(params.topic);
  if (!found || found.subject.id !== params.subject) notFound();
  const { subject, topic } = found;
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: row } = await supabase.from("topic_progress").select("topic_id").eq("user_id", user!.id).eq("topic_id", topic.id).maybeSingle();

  async function markDone() {
    "use server";
    const sb = createClient();
    const { data: { user } } = await sb.auth.getUser();
    if (user) await sb.from("topic_progress").upsert({ user_id: user.id, topic_id: topic.id });
    revalidatePath("/syllabus", "layout");
  }

  return (
    <div>
      <Link href={`/syllabus/${subject.id}`} className="text-sm text-leaf underline">{subject.name}</Link>
      <h1 className="mb-3 mt-2 font-display text-3xl font-bold">{topic.name}</h1>
      <div className="mb-5 flex flex-wrap gap-2">{topic.subs.map((s) => <span key={s} className="rounded-full bg-ink/10 px-3 py-1 text-sm dark:bg-white/10">{s}</span>)}</div>
      <div className="rounded-3xl bg-white p-5 dark:bg-nightcard"><Notes topicId={topic.id} /></div>
      <div className="mt-5 flex flex-wrap gap-3">
        <Link href={`/practice/topic?topic=${topic.id}`} className="rounded-xl bg-saffron px-4 py-2 font-semibold text-ink">Practice now</Link>
        <Link href="/tutor" className="rounded-xl border border-ink/20 px-4 py-2 font-medium">Ask the tutor</Link>
        {row ? <span className="px-2 py-2 font-medium text-leaf">Finished</span> : <form action={markDone}><button className="rounded-xl bg-ink px-4 py-2 font-medium text-white dark:bg-leaf">Mark as finished</button></form>}
      </div>
    </div>
  );
}
