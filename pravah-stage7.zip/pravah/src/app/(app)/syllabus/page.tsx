import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { SUBJECTS } from "@/lib/syllabus";
import { TREE, TOTAL_TOPICS } from "@/lib/topics";

export default async function Syllabus() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data } = await supabase.from("topic_progress").select("topic_id").eq("user_id", user!.id);
  const done = new Set((data ?? []).map((d) => d.topic_id));
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Syllabus</h1>
      <p className="mb-6 mt-1 opacity-70">{done.size} of {TOTAL_TOPICS} topics finished.</p>
      <ul className="space-y-3">
        {SUBJECTS.map((s) => {
          const topics = TREE[s.id] ?? [];
          const n = topics.filter((t) => done.has(t.id)).length;
          return (
            <li key={s.id}>
              <Link href={`/syllabus/${s.id}`} className="block rounded-2xl bg-white p-4 dark:bg-nightcard">
                <div className="flex justify-between gap-3"><span className="font-medium">{s.name}</span><span className="text-sm opacity-70">{n}/{topics.length}</span></div>
                <div className="mt-2 h-2 rounded-full bg-ink/10 dark:bg-white/10"><div className="h-2 rounded-full bg-leaf" style={{ width: `${topics.length ? (n / topics.length) * 100 : 0}%` }} /></div>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
