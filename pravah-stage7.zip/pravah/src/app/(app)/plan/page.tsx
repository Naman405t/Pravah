import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { loadStats } from "@/lib/stats";
import { adaptPlan, buildWeek, type PlanItem } from "@/lib/plan";
import { TREE } from "@/lib/topics";

export default async function PlanPage() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { data: sp } = await sb.from("study_plans").select("id,plan,daily_hours,exam_date").eq("user_id", user!.id).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (!sp) return <p>No plan yet. Finish setup from your Profile.</p>;
  const { stats, finished } = await loadStats(sb, user!.id);
  const fin: Record<string, { done: number; total: number }> = {};
  for (const [sid, ts] of Object.entries(TREE)) fin[sid] = { done: ts.filter((t) => finished.has(t.id)).length, total: ts.length };
  const hours = Number(sp.daily_hours) || 4;
  const items = adaptPlan(sp.plan as PlanItem[], hours, stats.perSubject, fin);
  const week = buildWeek(items, hours);
  const today = new Date().toLocaleDateString("en-US", { weekday: "short", timeZone: "Asia/Kolkata" });
  const left = sp.exam_date ? Math.ceil((new Date(sp.exam_date).getTime() - Date.now()) / 864e5) : null;
  const max = Math.max(...items.map((i) => i.hours));

  async function saveDate(fd: FormData) {
    "use server";
    const d = String(fd.get("date"));
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return;
    await createClient().from("study_plans").update({ exam_date: d }).eq("id", sp!.id);
    revalidatePath("/plan");
  }
  const card = "rounded-3xl bg-white p-5 dark:bg-nightcard";
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl font-bold">Study plan</h1>
      <section className={card}>
        <form action={saveDate} className="flex flex-wrap items-end gap-3">
          <label className="text-sm">Exam date<input type="date" name="date" defaultValue={sp.exam_date ?? ""} required className="mt-1 block rounded-xl border border-ink/20 bg-transparent px-3 py-2" /></label>
          <button className="rounded-xl bg-ink px-4 py-2 font-medium text-white dark:bg-leaf">Save date</button>
          {left !== null && <p className="font-display text-xl font-semibold">{left > 0 ? `${left} days to go` : left === 0 ? "Exam day" : "Exam date has passed"}</p>}
        </form>
      </section>
      <section className={card}>
        <h2 className="font-display text-xl font-semibold">This week, {hours * 7} hours</h2>
        <p className="mb-4 text-sm opacity-70">Updated from your practice accuracy and finished topics.</p>
        <ul className="space-y-3">
          {items.map((p) => (
            <li key={p.id}>
              <div className="flex justify-between gap-3 text-sm"><span>{p.name}</span><span className="shrink-0 font-semibold">{p.hours} h{p.hours !== p.baseHours ? ` (was ${p.baseHours})` : ""}</span></div>
              <div className="mt-1 h-2 rounded-full bg-ink/10 dark:bg-white/10"><div className="h-2 rounded-full bg-leaf" style={{ width: `${(p.hours / max) * 100}%` }} /></div>
              {p.note && <p className="mt-0.5 text-xs opacity-70">{p.note}</p>}
            </li>))}
        </ul>
      </section>
      <section className="grid gap-3 sm:grid-cols-2">
        {week.map((d) => (
          <div key={d.day} className={`${card} ${d.day === today ? "ring-2 ring-saffron" : ""}`}>
            <h3 className="font-display text-lg font-semibold">{d.day}{d.day === today ? " (today)" : ""}</h3>
            <ul className="mt-2 space-y-1 text-sm">{d.blocks.map((b, i) => <li key={i} className="flex justify-between gap-3"><span>{b.name}</span><b>{b.hours} h</b></li>)}</ul>
          </div>))}
      </section>
    </div>
  );
}
