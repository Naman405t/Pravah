import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { createClient } from "@/lib/supabase/server";
import Nav from "@/components/Nav";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("onboarded").eq("id", user.id).maybeSingle();
  if (!profile?.onboarded) redirect("/onboarding");
  return (
    <div className="min-h-screen">
      <Nav lang={cookies().get("lang")?.value === "hi" ? "hi" : "en"} />
      <main className="mx-auto max-w-3xl px-5 pb-28 pt-8 md:ml-60 md:pb-10">{children}</main>
    </div>
  );
}
