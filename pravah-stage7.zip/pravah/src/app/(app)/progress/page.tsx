import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { loadStats } from "@/lib/stats";
import { SUBJECTS } from "@/lib/syllabus";
import { findTopic } from "@/lib/topics";
import RevisionList from "@/components/RevisionList";

const barColor = (a: number) => (a < 0.6 ? "bg-red-500" : a < 0.8 ? "bg-saffron" : "bg-leaf");

export default async function Progress() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { stats } = await loadStats(sb, user!.id);
  const max = Math.max(1, ...stats.activity.map((a) => a.count));
  const card = "rounded-3xl bg-white p-5 dark:bg-nightcard";
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl font-bold">Progress</h1>
      {stats.total === 0 ? (
        <div className={card}><p>No practice data yet. Answer a few questions and your accuracy, speed and weak topics will show up here.</p>
          <Link href="/practice/topic" className="mt-3 inline-block font-medium text-leaf underline">Start topic practice</Link></div>
      ) : (<>
        <div className="grid grid-cols-3 gap-3 text-center">
          {[["Answered", stats.total], ["Accuracy", `${Math.round((stats.accuracy ?? 0) * 100)}%`], ["Day streak", stats.streak]].map(([l, v]) => (
            <div key={l} className={card}><p className="font-display text-3xl font-bold">{v}</p><p className="text-sm opacity-70">{l}</p></div>))}
        </div>
        <section className={card}>
          <h2 className="mb-3 font-display text-xl font-semibold">Last 14 days</h2>
          <div className="flex h-24 items-end gap-1.5">
            {stats.activity.map((a, i) => (<div key={i} className="flex flex-1 flex-col items-center gap-1">
              <div title={`${a.count} answered`} className="w-full rounded-t bg-leaf" style={{ height: `${(a.count / max) * 100}%`, minHeight: a.count ? 4 : 2, opacity: a.count ? 1 : 0.2 }} />
              <span className="text-[10px] opacity-60">{a.label}</span></div>))}
          </div>
        </section>
        <section className={card}>
          <h2 className="mb-3 font-display text-xl font-semibold">Accuracy and speed by subject</h2>
          <ul className="space-y-3">
            {SUBJECTS.map((s) => { const p = stats.perSubject[s.id]; return (
              <li key={s.id}>
                <div className="flex justify-between gap-3 text-sm"><span>{s.name}</span>
                  <span className="shrink-0 opacity-80">{p ? `${Math.round(p.acc! * 100)}% of ${p.attempted}${p.avgSec ? `, ${Math.round(p.avgSec)}s each` : ""}` : "No data"}</span></div>
                <div className="mt-1 h-2 rounded-full bg-ink/10 dark:bg-white/10">{p && <div className={`h-2 rounded-full ${barColor(p.acc!)}`} style={{ width: `${p.acc! * 100}%` }} />}</div>
              </li>); })}
          </ul>
        </section>
        <section className={card}>
          <h2 className="mb-3 font-display text-xl font-semibold">Weak topics</h2>
          {stats.weak.length ? <ul className="space-y-2">{stats.weak.map((w) => { const f = findTopic(w.id)!; return (
            <li key={w.id} className="flex justify-between gap-3"><span>{f.topic.name}</span>
              <Link href={`/practice/topic?topic=${w.id}`} className="shrink-0 text-leaf underline">{Math.round(w.acc * 100)}% of {w.attempted}</Link></li>); })}</ul>
            : <p className="opacity-70">No weak topics yet. A topic shows here after 3 or more answers with accuracy below 60%.</p>}
        </section>
      </>)}
      <section className={card}>
        <h2 className="mb-3 font-display text-xl font-semibold">Revise next</h2>
        <RevisionList items={stats.due} />
      </section>
    </div>
  );
}
