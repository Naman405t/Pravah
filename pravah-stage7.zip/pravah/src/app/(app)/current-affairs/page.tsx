import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { createClient } from "@/lib/supabase/server";
import { weekStart } from "@/lib/week";
import CAGenerate from "@/components/CAGenerate";
import QuizRunner from "@/components/QuizRunner";

export default async function CurrentAffairs() {
  const sb = createClient();
  const { data: row } = await sb.from("current_affairs").select("week_start,content_md,question_ids").order("week_start", { ascending: false }).limit(1).maybeSingle();
  const fresh = row?.week_start === weekStart();
  let qs: { id: string; stem: string; options: string[] }[] = [];
  if (row?.question_ids?.length) {
    const { data } = await sb.from("questions").select("id,stem,options").in("id", row.question_ids);
    qs = (data ?? []) as typeof qs;
  }
  const card = "rounded-3xl bg-white p-5 dark:bg-nightcard";
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl font-bold">Current affairs</h1>
      {!fresh && <section className={card}><p className="mb-3">{row ? `The latest summary is for the week of ${row.week_start}.` : "No summary yet."} Create this week's, built from a live news search.</p><CAGenerate /></section>}
      {row && (<>
        <section className={card}><p className="mb-2 text-sm opacity-60">Week of {row.week_start}</p>
          <div className="md"><ReactMarkdown remarkPlugins={[remarkGfm]}>{row.content_md}</ReactMarkdown></div>
          <p className="mt-4 text-xs opacity-60">AI-compiled from web search. Verify with the original sources (PIB, Ministry of Labour, EPFO) before relying on any item.</p></section>
        {qs.length > 0 && <section className={card}><h2 className="mb-3 font-display text-xl font-semibold">Quick quiz on this summary</h2><QuizRunner questions={qs} /></section>}
      </>)}
    </div>
  );
}
