import { createClient } from "@/lib/supabase/server";
import FlashReview from "@/components/FlashReview";

export default async function Flashcards() {
  const sb = createClient();
  const [{ data: due }, { count }] = await Promise.all([
    sb.from("flashcards").select("id,front,back").lte("due_at", new Date().toISOString()).order("due_at").limit(30),
    sb.from("flashcards").select("id", { count: "exact", head: true }),
  ]);
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Flashcards</h1>
      <p className="mb-6 mt-1 opacity-70">{count ?? 0} cards saved, {due?.length ?? 0} due now. Make more from any topic's notes or any tutor answer.</p>
      {due?.length ? <FlashReview cards={due} /> : <p>No cards are due. Open a topic's notes or a tutor answer and choose "Make flashcards".</p>}
    </div>
  );
}
