import { createClient } from "@/lib/supabase/server";
import Chat from "@/components/Chat";

export default async function Tutor({ searchParams }: { searchParams: { chat?: string } }) {
  const supabase = createClient();
  const { data: chats } = await supabase.from("chats").select("id,title").order("created_at", { ascending: false }).limit(30);
  let messages: { role: string; content: string }[] = [];
  if (searchParams.chat) {
    const { data } = await supabase.from("messages").select("role,content").eq("chat_id", searchParams.chat).order("created_at");
    messages = data ?? [];
  }
  return <Chat key={searchParams.chat ?? "new"} chatId={searchParams.chat ?? null} chats={chats ?? []} initial={messages} />;
}
