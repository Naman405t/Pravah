import { createClient } from "@/lib/supabase/server";
import BookmarkButton from "@/components/BookmarkButton";

export default async function Bookmarks() {
  const sb = createClient();
  const { data } = await sb.from("bookmarks").select("questions(id,stem,options,answer,explanation)").order("created_at", { ascending: false }).limit(100);
  const qs = (data ?? []).map((b) => (Array.isArray(b.questions) ? b.questions[0] : b.questions)).filter(Boolean) as { id: string; stem: string; options: string[]; answer: number; explanation: string }[];
  return (
    <div>
      <h1 className="mb-6 font-display text-3xl font-bold">Saved questions</h1>
      {!qs.length && <p className="opacity-70">Nothing saved yet. Use "Save question" after answering a practice or mock question.</p>}
      <ul className="space-y-3">
        {qs.map((q) => (
          <li key={q.id} className="rounded-2xl bg-white p-4 dark:bg-nightcard">
            <p className="font-medium">{q.stem}</p>
            <ol className="mt-2 list-[upper-alpha] pl-6 text-sm">{q.options.map((o, i) => <li key={i} className={i === q.answer ? "font-semibold text-leaf" : ""}>{o}</li>)}</ol>
            <p className="mt-2 text-sm opacity-80">{q.explanation}</p>
            <BookmarkButton questionId={q.id} initial />
          </li>))}
      </ul>
    </div>
  );
}
