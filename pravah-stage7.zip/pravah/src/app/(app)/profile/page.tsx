import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

async function signOut() {
  "use server";
  await createClient().auth.signOut();
  redirect("/");
}
async function setLang(fd: FormData) {
  "use server";
  const lang = fd.get("lang") === "hi" ? "hi" : "en";
  cookies().set("lang", lang, { path: "/", maxAge: 31536000 });
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  if (user) await sb.from("profiles").update({ language: lang }).eq("id", user.id);
  redirect("/profile");
}

export default async function Profile() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { data: sub } = await sb.from("subscriptions").select("plan,valid_until").eq("user_id", user!.id).maybeSingle();
  const pro = sub?.plan === "pro" && sub.valid_until && new Date(sub.valid_until) > new Date();
  const lang = cookies().get("lang")?.value === "hi" ? "hi" : "en";
  const link = "block font-medium text-leaf underline";
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl font-bold">Profile</h1>
      <p>{user?.email} <span className="ml-2 rounded-full bg-ink/10 px-2 py-0.5 text-sm dark:bg-white/10">{pro ? "Pro" : "Free"}</span></p>
      <form action={setLang} className="flex items-center gap-3">
        <span>Language</span>
        <button name="lang" value="en" className={`rounded-full px-4 py-1.5 text-sm font-medium ${lang === "en" ? "bg-ink text-white dark:bg-leaf" : "bg-ink/10 dark:bg-white/10"}`}>English</button>
        <button name="lang" value="hi" className={`rounded-full px-4 py-1.5 text-sm font-medium ${lang === "hi" ? "bg-ink text-white dark:bg-leaf" : "bg-ink/10 dark:bg-white/10"}`}>हिन्दी</button>
      </form>
      <p className="text-xs opacity-60">Hindi changes menu labels and tutor replies. Notes and questions stay in English for now.</p>
      <nav className="space-y-2">
        <Link href="/current-affairs" className={link}>Current affairs</Link>
        <Link href="/flashcards" className={link}>Flashcards</Link>
        <Link href="/bookmarks" className={link}>Saved questions</Link>
        <Link href="/pricing" className={link}>Free and Pro</Link>
        <Link href="/onboarding" className={link}>Redo setup and regenerate my plan</Link>
      </nav>
      <form action={signOut}><button className="rounded-xl border border-ink/20 px-4 py-2 font-medium">Sign out</button></form>
    </div>
  );
}
