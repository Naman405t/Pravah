import { createClient } from "@/lib/supabase/server";
import Checkout from "@/components/Checkout";

export default async function Pricing() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { data: sub } = await sb.from("subscriptions").select("plan,valid_until").eq("user_id", user!.id).maybeSingle();
  const pro = sub?.plan === "pro" && sub.valid_until && new Date(sub.valid_until) > new Date();
  const row = (t: string, a: string, b: string) => <tr key={t} className="border-t border-ink/10 dark:border-white/10"><td className="py-2">{t}</td><td>{a}</td><td className="font-semibold">{b}</td></tr>;
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl font-bold">Free and Pro</h1>
      {pro && <p className="rounded-2xl bg-leaf/15 p-4 font-medium text-leaf">Pro is active until {new Date(sub!.valid_until!).toLocaleDateString("en-IN")}. Buying again adds time.</p>}
      <table className="w-full rounded-3xl bg-white p-4 text-left text-sm dark:bg-nightcard">
        <thead><tr><th className="p-2"></th><th>Free</th><th>Pro</th></tr></thead>
        <tbody>{[row("Tutor and Snap messages", "20 a day", "No daily cap"), row("Practice questions", "100 a day", "No daily cap"), row("Notes, syllabus, plan, progress", "Included", "Included"), row("Mock tests, flashcards, current affairs", "Included", "Included")]}</tbody>
      </table>
      <Checkout />
      <p className="text-xs opacity-60">Payments are processed by Razorpay. Prices shown are set by the site owner.</p>
    </div>
  );
}
