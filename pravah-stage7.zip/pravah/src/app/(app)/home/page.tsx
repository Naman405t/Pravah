import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { loadStats } from "@/lib/stats";
import RevisionList from "@/components/RevisionList";

export default async function HomePage() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const [{ data: profile }, { stats }] = await Promise.all([
    sb.from("profiles").select("full_name").eq("id", user!.id).single(),
    loadStats(sb, user!.id),
  ]);
  const card = "rounded-3xl bg-white p-6 dark:bg-nightcard";
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl font-bold">Hi {profile?.full_name?.split(" ")[0] || "there"}</h1>
      <div className="grid grid-cols-3 gap-3 text-center">
        <div className={card}><p className="font-display text-3xl font-bold">{stats.streak}</p><p className="text-sm opacity-70">Day streak</p></div>
        <div className={card}><p className="font-display text-3xl font-bold">{stats.accuracy === null ? "-" : `${Math.round(stats.accuracy * 100)}%`}</p><p className="text-sm opacity-70">Accuracy</p></div>
        <div className={card}><p className="font-display text-3xl font-bold">{stats.total}</p><p className="text-sm opacity-70">Answered</p></div>
      </div>
      <section className={card}>
        <h2 className="mb-3 font-display text-xl font-semibold">Revise next</h2>
        <RevisionList items={stats.due.slice(0, 3)} />
        <Link href="/progress" className="mt-4 inline-block font-medium text-leaf underline">See full progress</Link>
      </section>
      <section className={card}>
        <h2 className="font-display text-xl font-semibold">Get help now</h2>
        <div className="mt-3 flex flex-wrap gap-3">
          <Link href="/tutor" className="rounded-xl bg-ink px-4 py-2 font-medium text-white dark:bg-leaf">Ask the tutor</Link>
          <Link href="/snap" className="rounded-xl bg-saffron px-4 py-2 font-medium text-ink">Snap a question</Link>
          <Link href="/syllabus" className="rounded-xl border border-ink/20 px-4 py-2 font-medium">Study the syllabus</Link>
          <Link href="/plan" className="rounded-xl border border-ink/20 px-4 py-2 font-medium">Open my plan</Link>
        </div>
      </section>
    </div>
  );
}
