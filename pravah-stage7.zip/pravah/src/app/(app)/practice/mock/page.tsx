import MockCreate from "@/components/MockCreate";
export default function Page() {
  return (<div><h1 className="mb-6 font-display text-3xl font-bold">Mock tests</h1><MockCreate /></div>);
}
