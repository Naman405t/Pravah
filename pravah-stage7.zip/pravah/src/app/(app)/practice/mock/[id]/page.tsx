import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import MockRunner from "@/components/MockRunner";

export default async function MockPage({ params }: { params: { id: string } }) {
  const sb = createClient();
  const { data: mock } = await sb.from("mock_tests").select("title,question_ids,duration_min").eq("id", params.id).maybeSingle();
  if (!mock) notFound();
  const { data } = await sb.from("questions").select("id,stem,options").in("id", mock.question_ids);
  const byId = new Map((data ?? []).map((q) => [q.id, q]));
  const questions = (mock.question_ids as string[]).map((id) => byId.get(id)).filter(Boolean) as { id: string; stem: string; options: string[] }[];
  return (<div><h1 className="mb-4 font-display text-2xl font-bold">{mock.title}</h1><MockRunner mockId={params.id} questions={questions} minutes={mock.duration_min} /></div>);
}
