import Link from "next/link";

const CARDS = [
  { href: "/practice/topic", title: "Topic practice", text: "AI-made MCQs on any topic, with instant explanations." },
  { href: "/practice/mock", title: "Mock tests", text: "Timed papers across all subjects with negative marking." },
  { href: "/practice/pyq", title: "Previous year questions", text: "Real past questions, filtered by subject." },
  { href: "/practice/interview", title: "Mock interview", text: "Practise the personality test with an AI panel member." },
];
export default function Practice() {
  return (
    <div>
      <h1 className="mb-6 font-display text-3xl font-bold">Practice</h1>
      <div className="grid gap-3 sm:grid-cols-2">
        {CARDS.map((c) => <Link key={c.href} href={c.href} className="rounded-2xl bg-white p-5 dark:bg-nightcard"><span className="font-display text-xl font-semibold">{c.title}</span><span className="mt-1 block opacity-70">{c.text}</span></Link>)}
      </div>
    </div>
  );
}
