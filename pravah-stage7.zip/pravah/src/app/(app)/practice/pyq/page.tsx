import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { SUBJECTS } from "@/lib/syllabus";

export default async function Pyq({ searchParams }: { searchParams: { subject?: string } }) {
  const sb = createClient();
  let q = sb.from("pyq").select("id,year,stem,options,answer,explanation").order("year", { ascending: false }).limit(60);
  if (searchParams.subject) q = q.like("topic_id", `${searchParams.subject}-%`);
  const { data } = await q;
  return (
    <div>
      <h1 className="mb-4 font-display text-3xl font-bold">Previous year questions</h1>
      <div className="mb-5 flex flex-wrap gap-2">
        <Link href="/practice/pyq" className="rounded-full bg-ink/10 px-3 py-1 text-sm dark:bg-white/10">All</Link>
        {SUBJECTS.map((s) => <Link key={s.id} href={`/practice/pyq?subject=${s.id}`} className={`rounded-full px-3 py-1 text-sm ${searchParams.subject === s.id ? "bg-ink text-white dark:bg-leaf" : "bg-ink/10 dark:bg-white/10"}`}>{s.name}</Link>)}
      </div>
      {!data?.length && <p className="opacity-70">No questions here yet. The admin can import them into the pyq table (see README).</p>}
      <ul className="space-y-3">
        {data?.map((p) => (
          <li key={p.id} className="rounded-2xl bg-white p-4 dark:bg-nightcard">
            <p className="text-sm opacity-60">{p.year}</p>
            <p className="font-medium">{p.stem}</p>
            <ol className="mt-2 list-[upper-alpha] pl-6 text-sm">{(p.options as string[]).map((o, i) => <li key={i}>{o}</li>)}</ol>
            <details className="mt-2"><summary className="cursor-pointer text-sm font-medium text-leaf">Show answer</summary>
              <p className="mt-1 text-sm"><b>Answer: {"ABCD"[p.answer]}.</b> {p.explanation}</p></details>
          </li>
        ))}
      </ul>
    </div>
  );
}
