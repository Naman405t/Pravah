import { createClient } from "@/lib/supabase/server";
import Chat from "@/components/Chat";

export default async function Interview({ searchParams }: { searchParams: { chat?: string } }) {
  const sb = createClient();
  const { data: chats } = await sb.from("chats").select("id,title").eq("mode", "interview").order("created_at", { ascending: false }).limit(30);
  let messages: { role: string; content: string }[] = [];
  if (searchParams.chat) {
    const { data } = await sb.from("messages").select("role,content").eq("chat_id", searchParams.chat).order("created_at");
    messages = data ?? [];
  }
  return <Chat key={searchParams.chat ?? "new"} chatId={searchParams.chat ?? null} chats={chats ?? []} initial={messages} fixedMode="interview" basePath="/practice/interview" />;
}
