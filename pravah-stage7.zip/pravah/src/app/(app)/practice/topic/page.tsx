import TopicPractice from "@/components/TopicPractice";
export default function Page({ searchParams }: { searchParams: { topic?: string } }) {
  return (<div><h1 className="mb-6 font-display text-3xl font-bold">Topic practice</h1><TopicPractice initialTopic={searchParams.topic} /></div>);
}
