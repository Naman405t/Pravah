"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { BRAND } from "@/lib/brand";

export default function Login() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [signup, setSignup] = useState(false);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMsg("");
    const { data, error } = signup
      ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/auth/callback` } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) return setMsg(error.message);
    if (signup && !data.session) return setMsg("Check your inbox and click the confirmation link to finish signing up.");
    router.push("/home"); router.refresh();
  }

  const google = () => supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${location.origin}/auth/callback` } });
  const input = "w-full rounded-xl border border-ink/20 bg-transparent px-4 py-3";

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-5">
      <h1 className="font-display text-3xl font-bold">{signup ? `Join ${BRAND}` : "Welcome back"}</h1>
      <button onClick={google} className="mt-6 rounded-xl border border-ink/20 px-4 py-3 font-medium hover:bg-ink/5">Continue with Google</button>
      <p className="my-4 text-center text-sm opacity-60">or use email</p>
      <form onSubmit={submit} className="space-y-3">
        <input className={input} type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className={input} type="password" required minLength={6} placeholder="Password (6+ characters)" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button disabled={busy} className="w-full rounded-xl bg-ink px-4 py-3 font-semibold text-white disabled:opacity-60 dark:bg-leaf">{signup ? "Create account" : "Sign in"}</button>
      </form>
      {msg && <p role="alert" className="mt-3 text-sm text-red-600">{msg}</p>}
      <button onClick={() => setSignup(!signup)} className="mt-6 text-sm underline">{signup ? "I already have an account" : "Create a new account"}</button>
    </main>
  );
}
