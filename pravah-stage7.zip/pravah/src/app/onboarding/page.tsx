import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { SUBJECTS } from "@/lib/syllabus";
import { buildPlan } from "@/lib/plan";

async function save(fd: FormData) {
  "use server";
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const hours = Math.min(14, Math.max(1, Number(fd.get("hours")) || 4));
  const weak = fd.getAll("weak").map(String);
  const { error } = await supabase.from("profiles").upsert({
    id: user.id, full_name: String(fd.get("name") || ""), target_exam: "APFC",
    attempt_year: Number(fd.get("year")) || new Date().getFullYear(),
    daily_hours: hours, weak_subjects: weak, onboarded: true,
  });
  if (error) throw new Error(error.message);
  await supabase.from("study_plans").delete().eq("user_id", user.id);
  await supabase.from("study_plans").insert({ user_id: user.id, daily_hours: hours, plan: buildPlan(hours, weak) });
  redirect("/home");
}

export default function Onboarding() {
  const field = "w-full rounded-xl border border-ink/20 bg-transparent px-4 py-3";
  return (
    <main className="mx-auto max-w-xl px-5 py-10">
      <h1 className="font-display text-3xl font-bold">Set up your study plan</h1>
      <p className="mt-2 opacity-70">Four quick questions. You can change them later in Profile.</p>
      <form action={save} className="mt-8 space-y-6">
        <label className="block">Your name<input name="name" required className={`${field} mt-1`} /></label>
        <label className="block">Exam
          <select name="exam" className={`${field} mt-1`}><option>UPSC EPFO APFC</option></select></label>
        <div className="grid grid-cols-2 gap-4">
          <label className="block">Attempt year<input name="year" type="number" defaultValue={new Date().getFullYear()} className={`${field} mt-1`} /></label>
          <label className="block">Study hours per day<input name="hours" type="number" min={1} max={14} step={0.5} defaultValue={4} className={`${field} mt-1`} /></label>
        </div>
        <fieldset>
          <legend className="mb-2">Which subjects feel weak? (they get 50% more time)</legend>
          <div className="grid gap-2 sm:grid-cols-2">
            {SUBJECTS.map((s) => (
              <label key={s.id} className="flex items-center gap-2 rounded-xl border border-ink/15 px-3 py-2 text-sm">
                <input type="checkbox" name="weak" value={s.id} />{s.name}</label>
            ))}
          </div>
        </fieldset>
        <button className="w-full rounded-xl bg-saffron px-4 py-3 font-semibold text-ink">Create my plan</button>
      </form>
    </main>
  );
}
