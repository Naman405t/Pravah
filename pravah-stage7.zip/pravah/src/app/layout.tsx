import type { Metadata } from "next";
import { Bricolage_Grotesque, Hind } from "next/font/google";
import { BRAND, TAGLINE } from "@/lib/brand";
import "./globals.css";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display" });
const body = Hind({ subsets: ["latin", "devanagari"], weight: ["400", "500", "600"], variable: "--font-body" });

export const metadata: Metadata = { title: `${BRAND} | APFC exam prep`, description: TAGLINE };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: `try{if(localStorage.theme==='dark')document.documentElement.classList.add('dark')}catch(e){}` }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
