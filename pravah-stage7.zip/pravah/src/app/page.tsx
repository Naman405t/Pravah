import Link from "next/link";
import { BRAND, TAGLINE } from "@/lib/brand";
import { SUBJECTS } from "@/lib/syllabus";
import { PLANS } from "@/lib/billing";
import ThemeToggle from "@/components/ThemeToggle";

const FEATURES = [
  ["AI tutor in three modes", "Get step-by-step solutions, guided questions, or short exam-style answers."],
  ["Snap and solve", "Photograph a question and get the answer plus its syllabus topic."],
  ["Syllabus-mapped notes", "All 16 subjects broken into topics, with notes and quick revision."],
  ["Practice and mock tests", "Timed papers across subjects with negative marking and explanations."],
  ["Weak-topic tracking", "See accuracy by subject and get a daily list of what to revise next."],
  ["Adaptive study plan", "Weekly hours shift towards the subjects where you lose marks."],
];
const FAQ = [
  ["Which exam is this for?", "The UPSC EPFO Recruitment Test for Assistant Provident Fund Commissioner (APFC)."],
  ["Are the AI answers always right?", "No. AI can make mistakes, especially on Act sections and recent news. Verify important facts with official sources."],
  ["Is it free?", "Yes, with daily limits. Pro removes the limits."],
  ["Is this an official UPSC or EPFO product?", `No. ${BRAND} is an independent study tool and is not affiliated with UPSC or EPFO.`],
];

export default function Landing() {
  return (
    <main className="mx-auto max-w-5xl px-5 py-6">
      <header className="flex items-center justify-between">
        <span className="font-display text-2xl font-bold">{BRAND}</span>
        <div className="flex items-center gap-2"><ThemeToggle />
          <Link href="/login" className="rounded-full bg-ink px-5 py-2 font-medium text-white dark:bg-leaf">Sign in</Link></div>
      </header>
      <section className="grid gap-10 py-16 md:grid-cols-2 md:items-center">
        <div>
          <h1 className="font-display text-4xl font-bold leading-tight md:text-5xl">Clear the APFC recruitment test with a plan built around its 16 subjects.</h1>
          <p className="mt-5 max-w-md text-lg opacity-80">{TAGLINE}. Ask doubts, practice MCQs, and see which topics need work next.</p>
          <Link href="/login" className="mt-8 inline-block rounded-full bg-saffron px-7 py-3 font-semibold text-ink">Start free</Link>
        </div>
        <div className="rounded-3xl bg-white p-6 shadow-sm dark:bg-nightcard">
          <p className="mb-4 font-display text-lg font-semibold">Syllabus covered</p>
          <ul className="grid grid-cols-1 gap-x-4 gap-y-1.5 text-sm sm:grid-cols-2">
            {SUBJECTS.map((s) => <li key={s.id} className="border-b border-ink/10 py-1 dark:border-white/10">{s.name}</li>)}
          </ul>
        </div>
      </section>
      <section className="grid gap-4 py-8 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(([t, d]) => <div key={t} className="rounded-2xl bg-white p-5 dark:bg-nightcard"><h2 className="font-display text-lg font-semibold">{t}</h2><p className="mt-1 text-sm opacity-80">{d}</p></div>)}
      </section>
      <section className="py-10">
        <h2 className="mb-5 font-display text-2xl font-bold">Pricing</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-2xl bg-white p-5 dark:bg-nightcard"><p className="font-display text-xl font-semibold">Free</p><p className="text-2xl font-bold">Rs. 0</p><p className="mt-1 text-sm opacity-80">20 tutor messages and 100 practice questions a day</p></div>
          {PLANS.map((p) => <div key={p.id} className="rounded-2xl bg-ink p-5 text-white dark:bg-leaf"><p className="font-display text-xl font-semibold">{p.name}</p><p className="text-2xl font-bold">Rs. {p.price}</p><p className="mt-1 text-sm opacity-80">No daily caps</p></div>)}
        </div>
      </section>
      <section className="py-8">
        <h2 className="mb-4 font-display text-2xl font-bold">Questions</h2>
        {FAQ.map(([q, a]) => <details key={q} className="border-b border-ink/10 py-3 dark:border-white/10"><summary className="cursor-pointer font-medium">{q}</summary><p className="mt-2 opacity-80">{a}</p></details>)}
      </section>
      <footer className="py-8 text-sm opacity-60">{BRAND} is an independent study tool, not affiliated with UPSC or EPFO.</footer>
    </main>
  );
}
