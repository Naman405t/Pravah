// Monday of the current week in Indian time, as YYYY-MM-DD
export function weekStart(now = new Date()) {
  const d = new Date(now.getTime() + 5.5 * 3600e3);
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
  return d.toISOString().slice(0, 10);
}
