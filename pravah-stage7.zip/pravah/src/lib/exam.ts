// Set these from the latest official UPSC EPFO notification.
export const MARK_CORRECT = 1;
export const NEGATIVE = 1 / 3; // deducted per wrong answer
export const MOCKS = {
  mini: { label: "Mini mock", questions: 20, minutes: 24 },
  full: { label: "Full mock", questions: 50, minutes: 60 },
} as const;
export const score = (correct: number, wrong: number) => Math.round((correct * MARK_CORRECT - wrong * NEGATIVE) * 100) / 100;
