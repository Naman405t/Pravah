// Placeholder prices in rupees. Change to your own.
export const PLANS = [
  { id: "month", name: "Pro, 1 month", price: 299, days: 30 },
  { id: "quarter", name: "Pro, 3 months", price: 699, days: 90 },
] as const;
export const rzpAuth = () => "Basic " + Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString("base64");
