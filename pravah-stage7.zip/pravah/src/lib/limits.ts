import type { SupabaseClient } from "@supabase/supabase-js";
export const FREE_DAILY_QUESTIONS = 100;

export async function practiceBlocked(sb: SupabaseClient, userId: string): Promise<string | null> {
  const since = new Date(); since.setUTCHours(0, 0, 0, 0);
  const [{ count }, { data: sub }] = await Promise.all([
    sb.from("attempts").select("id", { count: "exact", head: true }).eq("user_id", userId).gte("created_at", since.toISOString()),
    sb.from("subscriptions").select("plan,valid_until").eq("user_id", userId).maybeSingle(),
  ]);
  const pro = sub?.plan === "pro" && (!sub.valid_until || new Date(sub.valid_until) > new Date());
  return !pro && (count ?? 0) >= FREE_DAILY_QUESTIONS ? `You have used today's ${FREE_DAILY_QUESTIONS} free practice questions. Come back tomorrow or upgrade.` : null;
}
