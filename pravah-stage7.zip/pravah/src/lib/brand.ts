export const BRAND = "Pravah"; // change this to your own brand name
export const TAGLINE = "Your AI mentor for the UPSC EPFO APFC exam";
