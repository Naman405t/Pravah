import { SUBJECTS } from "./syllabus";

export type PlanItem = { id: string; name: string; hours: number };

// Splits weekly study hours across subjects; weak subjects get 1.5x time.
export function buildPlan(dailyHours: number, weak: string[]): PlanItem[] {
  const weekly = dailyHours * 7;
  const w = SUBJECTS.map((s) => s.weight * (weak.includes(s.id) ? 1.5 : 1));
  const total = w.reduce((a, b) => a + b, 0);
  return SUBJECTS.map((s, i) => ({
    id: s.id,
    name: s.name,
    hours: Math.max(0.5, Math.round(((w[i] / total) * weekly) * 2) / 2),
  }));
}

export type AdaptedItem = PlanItem & { baseHours: number; note: string };

// Re-balances the weekly hours using practice accuracy and syllabus completion.
export function adaptPlan(
  base: PlanItem[], dailyHours: number,
  perSubject: Record<string, { attempted: number; acc: number | null }>,
  finishedBySubject: Record<string, { done: number; total: number }>,
): AdaptedItem[] {
  const raw = base.map((p) => {
    const s = perSubject[p.id], f = finishedBySubject[p.id];
    let m = 1, note = "";
    if (s && s.acc !== null && s.attempted >= 5) {
      if (s.acc < 0.6) { m = 1.4; note = `More time: accuracy ${Math.round(s.acc * 100)}%`; }
      else if (s.acc < 0.75) { m = 1.1; note = `Slightly more: accuracy ${Math.round(s.acc * 100)}%`; }
      else if (s.acc >= 0.85 && s.attempted >= 10) { m = 0.8; note = `Less time: accuracy ${Math.round(s.acc * 100)}%`; }
    }
    if (f && f.total > 0 && f.done === f.total) { m *= 0.7; note = "Syllabus finished: revision only"; }
    return { p, v: p.hours * m, note };
  });
  const sum = raw.reduce((a, r) => a + r.v, 0);
  const scale = (dailyHours * 7) / sum;
  return raw.map(({ p, v, note }) => ({ ...p, baseHours: p.hours, hours: Math.max(0.5, Math.round(v * scale * 2) / 2), note }));
}

// Spreads the week's hours into 1-hour chunks, interleaved so a day mixes subjects.
export function buildWeek(items: PlanItem[], dailyHours: number) {
  const queues = [...items].sort((a, b) => b.hours - a.hours).map((i) => {
    const q: { name: string; hours: number }[] = []; let left = i.hours;
    while (left > 0) { const h = Math.min(1, left); q.push({ name: i.name, hours: h }); left -= h; }
    return q;
  });
  const seq: { name: string; hours: number }[] = [];
  while (queues.some((q) => q.length)) for (const q of queues) { const c = q.shift(); if (c) seq.push(c); }
  const names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  let p = 0;
  return names.map((day) => {
    const blocks: { name: string; hours: number }[] = []; let t = 0;
    while (t < dailyHours - 0.25 && seq.length) {
      const c = seq[p++ % seq.length], last = blocks[blocks.length - 1];
      if (last && last.name === c.name) last.hours += c.hours; else blocks.push({ ...c });
      t += c.hours;
    }
    return { day, blocks };
  });
}
