// Subjects from the official-style APFC syllabus. weight = relative share of study time.
export const SUBJECTS = [
  { id: "english", name: "English Language", weight: 1.0 },
  { id: "culture", name: "Indian Culture, Heritage & Freedom Movements", weight: 1.3 },
  { id: "current", name: "Current Events", weight: 1.3 },
  { id: "development", name: "Developmental Issues", weight: 0.5 },
  { id: "polity", name: "Governance & Constitution of India", weight: 1.2 },
  { id: "economy", name: "Present Trends in Indian Economy", weight: 1.2 },
  { id: "accounting", name: "Accounting", weight: 1.3 },
  { id: "auditing", name: "Auditing", weight: 1.0 },
  { id: "labour", name: "Industrial Relations & Labour Codes", weight: 1.5 },
  { id: "insurance", name: "Insurance", weight: 0.8 },
  { id: "computer", name: "Basic Computer Applications", weight: 0.6 },
  { id: "science", name: "General Science", weight: 0.9 },
  { id: "maths", name: "Elementary Mathematics", weight: 1.0 },
  { id: "statistics", name: "Statistics", weight: 0.6 },
  { id: "reasoning", name: "General Mental Ability", weight: 0.9 },
  { id: "social", name: "Social Security in India", weight: 1.5 },
] as const;
