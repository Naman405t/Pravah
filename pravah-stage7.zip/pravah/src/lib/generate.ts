import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@supabase/supabase-js";
import { findTopic } from "./topics";
import { buildSystem } from "./prompts";

export type Q = { id: string; stem: string; options: string[] };
export const shuffle = <T,>(a: T[]) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };

export function getAdmin() {
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) return null;
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY);
}

// Asks Claude for MCQs, validates them, stores them in the shared question bank, returns them without answers.
export async function generateQuestions(topicId: string, difficulty: string, count: number): Promise<Q[]> {
  const found = findTopic(topicId);
  const admin = getAdmin();
  if (!found || !admin) throw new Error("Question generation is not configured (missing SUPABASE_SERVICE_ROLE_KEY).");
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const r = await client.messages.create({
    model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
    max_tokens: Math.min(4000, 450 * count + 300),
    system: `${buildSystem("exam")}\nYou output only valid JSON, with no commentary and no code fences.`,
    messages: [{ role: "user", content: `Write ${count} ${difficulty} multiple-choice questions in UPSC EPFO APFC Recruitment Test style.
Subject: ${found.subject.name}. Topic: ${found.topic.name}. Cover these subtopics: ${found.topic.subs.join("; ")}.
Rules: exactly 4 options, exactly one correct; vary the position of the correct option; test facts you are certain of (for Acts and Codes, avoid section numbers unless sure); explanation in 1 to 2 sentences.
Output a JSON array: [{"stem":"...","options":["...","...","...","..."],"answer":0,"explanation":"..."}] where answer is the index 0 to 3.` }],
  });
  const text = r.content.map((b) => (b.type === "text" ? b.text : "")).join("").replace(/```json|```/g, "").trim();
  const arr = JSON.parse(text.slice(text.indexOf("["), text.lastIndexOf("]") + 1));
  const rows = (Array.isArray(arr) ? arr : []).filter((q) =>
    typeof q?.stem === "string" && Array.isArray(q.options) && q.options.length === 4 && q.options.every((o: unknown) => typeof o === "string") && Number.isInteger(q.answer) && q.answer >= 0 && q.answer < 4
  ).map((q) => ({ topic_id: topicId, stem: q.stem, options: q.options, answer: q.answer, explanation: String(q.explanation ?? ""), difficulty, source: "ai" }));
  if (!rows.length) throw new Error("The AI returned no usable questions. Please retry.");
  const { data, error } = await admin.from("questions").insert(rows).select("id,stem,options");
  if (error) throw new Error(error.message);
  return data as Q[];
}

// Makes MCQs from a block of text (used for the weekly current-affairs quiz).
export async function questionsFromText(topicId: string, text: string, count: number, source: string): Promise<Q[]> {
  const admin = getAdmin();
  if (!admin) throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY.");
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const r = await client.messages.create({
    model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 2500,
    system: "You write exam MCQs. Output only a valid JSON array, no commentary, no code fences.",
    messages: [{ role: "user", content: `Using ONLY the facts in this text, write ${count} multiple-choice questions in UPSC EPFO APFC style. Exactly 4 options, one correct, vary the correct position, 1 sentence explanation. Format: [{"stem":"","options":["","","",""],"answer":0,"explanation":""}]\n\nTEXT:\n${text.slice(0, 8000)}` }],
  });
  const t = r.content.map((b) => (b.type === "text" ? b.text : "")).join("").replace(/```json|```/g, "").trim();
  const arr = JSON.parse(t.slice(t.indexOf("["), t.lastIndexOf("]") + 1));
  const rows = (Array.isArray(arr) ? arr : []).filter((q) => typeof q?.stem === "string" && Array.isArray(q.options) && q.options.length === 4 && Number.isInteger(q.answer) && q.answer >= 0 && q.answer < 4)
    .map((q) => ({ topic_id: topicId, stem: q.stem, options: q.options, answer: q.answer, explanation: String(q.explanation ?? ""), difficulty: "medium", source }));
  if (!rows.length) throw new Error("No usable questions.");
  const { data, error } = await admin.from("questions").insert(rows).select("id,stem,options");
  if (error) throw new Error(error.message);
  return data as Q[];
}
