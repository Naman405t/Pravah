import type { SupabaseClient } from "@supabase/supabase-js";

// Review gaps for spaced repetition (days). Tune to taste.
const GAP = { weak: 1, mid: 3, good: 7, mastered: 14 };
const DAY = 864e5;
const istDay = (d: Date | string) => new Date(d).toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });

export type Row = { correct: boolean | null; chosen: number | null; seconds: number | null; created_at: string; questions: { topic_id: string } | { topic_id: string }[] | null };
type Agg = { attempted: number; correct: number; secs: number; timed: number; last: string };
export type SubjectStat = { attempted: number; acc: number | null; avgSec: number | null };

export function computeStats(rows: Row[], finished: Set<string>, now = new Date()) {
  const subj: Record<string, Agg> = {}, topic: Record<string, Agg> = {}, days = new Map<string, number>();
  let total = 0, correct = 0;
  const bump = (m: Record<string, Agg>, k: string, r: Row) => {
    const a = (m[k] ??= { attempted: 0, correct: 0, secs: 0, timed: 0, last: r.created_at });
    a.attempted++; if (r.correct) a.correct++;
    if (r.seconds && r.seconds > 0) { a.secs += r.seconds; a.timed++; }
    if (r.created_at > a.last) a.last = r.created_at;
  };
  for (const r of rows) {
    const q = Array.isArray(r.questions) ? r.questions[0] : r.questions;
    if (!q?.topic_id || r.chosen === null) continue;
    total++; if (r.correct) correct++;
    bump(subj, q.topic_id.split("-")[0], r); bump(topic, q.topic_id, r);
    const d = istDay(r.created_at); days.set(d, (days.get(d) ?? 0) + 1);
  }

  let streak = 0;
  let i = days.has(istDay(now)) ? 0 : 1;
  while (days.has(istDay(new Date(now.getTime() - i * DAY)))) { streak++; i++; }

  const perSubject: Record<string, SubjectStat> = {};
  for (const [k, a] of Object.entries(subj)) perSubject[k] = { attempted: a.attempted, acc: a.correct / a.attempted, avgSec: a.timed ? a.secs / a.timed : null };

  const weak = Object.entries(topic).filter(([, a]) => a.attempted >= 3 && a.correct / a.attempted < 0.6)
    .map(([id, a]) => ({ id, acc: a.correct / a.attempted, attempted: a.attempted })).sort((x, y) => x.acc - y.acc).slice(0, 6);

  const due: { id: string; reason: string; overdue: number; weak: boolean }[] = [];
  for (const [id, a] of Object.entries(topic)) {
    const acc = a.correct / a.attempted;
    const gap = acc < 0.6 ? GAP.weak : acc < 0.8 ? GAP.mid : a.attempted >= 10 ? GAP.mastered : GAP.good;
    const since = Math.floor((now.getTime() - new Date(a.last).getTime()) / DAY);
    if (since >= gap) due.push({ id, overdue: since - gap, weak: acc < 0.6,
      reason: acc < 0.6 ? `Accuracy ${Math.round(acc * 100)}%. Revisit the notes and re-test.` : `Last practised ${since} day${since === 1 ? "" : "s"} ago.` });
  }
  for (const id of finished) if (!topic[id]) due.push({ id, overdue: 0, weak: false, reason: "Finished but never practised." });
  due.sort((a, b) => Number(b.weak) - Number(a.weak) || b.overdue - a.overdue);

  const activity = Array.from({ length: 14 }, (_, n) => { const d = new Date(now.getTime() - (13 - n) * DAY); const key = istDay(d); return { label: key.slice(8), count: days.get(key) ?? 0 }; });
  return { total, correct, accuracy: total ? correct / total : null, streak, perSubject, weak, due: due.slice(0, 6), activity };
}
export type Stats = ReturnType<typeof computeStats>;

export async function loadStats(sb: SupabaseClient, userId: string) {
  const [{ data: rows }, { data: prog }] = await Promise.all([
    sb.from("attempts").select("correct,chosen,seconds,created_at,questions(topic_id)").eq("user_id", userId).order("created_at", { ascending: false }).limit(5000),
    sb.from("topic_progress").select("topic_id").eq("user_id", userId),
  ]);
  const finished = new Set((prog ?? []).map((p) => p.topic_id as string));
  return { stats: computeStats((rows ?? []) as unknown as Row[], finished), finished };
}
