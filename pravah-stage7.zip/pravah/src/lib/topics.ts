import data from "./syllabus-data.json";
import { SUBJECTS } from "./syllabus";

export type Topic = { id: string; name: string; subs: string[] };
export const TREE = data as Record<string, Topic[]>;
export const subjectById = (id: string) => SUBJECTS.find((s) => s.id === id);
export const findTopic = (id: string) => {
  const sid = id.split("-")[0];
  const topic = TREE[sid]?.find((t) => t.id === id);
  return topic ? { subject: subjectById(sid)!, topic } : null;
};
export const TOTAL_TOPICS = Object.values(TREE).reduce((n, t) => n + t.length, 0);
