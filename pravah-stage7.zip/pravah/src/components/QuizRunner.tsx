"use client";
import { useRef, useState } from "react";
import Options from "./Options";
import BookmarkButton from "./BookmarkButton";

type Q = { id: string; stem: string; options: string[] };
type R = { correct: boolean; chosen: number | null; answer: number; explanation: string };

export default function QuizRunner({ questions }: { questions: Q[] }) {
  const [i, setI] = useState(0);
  const [sel, setSel] = useState<number | null>(null);
  const [res, setRes] = useState<R | null>(null);
  const [right, setRight] = useState(0);
  const [err, setErr] = useState("");
  const t0 = useRef(Date.now());
  async function check() {
    const r = await fetch("/api/attempts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ attempts: [{ questionId: questions[i].id, chosen: sel, seconds: (Date.now() - t0.current) / 1000 }] }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return setErr(j.error || "Something went wrong.");
    setRes(j.results[0]); if (j.results[0].correct) setRight((n) => n + 1);
  }
  if (i >= questions.length) return <p className="font-medium">Quiz done: {right} of {questions.length} correct.</p>;
  return (
    <div className="space-y-3">
      <p className="text-sm opacity-70">Question {i + 1} of {questions.length}</p>
      <Options stem={questions[i].stem} options={questions[i].options} chosen={res ? res.chosen : sel} onChoose={setSel} locked={!!res} answer={res?.answer} />
      {res && <><p className="rounded-xl bg-ink/5 p-3 text-sm dark:bg-white/10">{res.explanation}</p><BookmarkButton questionId={questions[i].id} /></>}
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
      {res ? <button onClick={() => { setI(i + 1); setSel(null); setRes(null); t0.current = Date.now(); }} className="rounded-xl bg-ink px-4 py-2 font-medium text-white dark:bg-leaf">{i + 1 === questions.length ? "Finish" : "Next"}</button>
        : <button disabled={sel === null} onClick={check} className="rounded-xl bg-saffron px-4 py-2 font-semibold text-ink disabled:opacity-50">Check answer</button>}
    </div>
  );
}
