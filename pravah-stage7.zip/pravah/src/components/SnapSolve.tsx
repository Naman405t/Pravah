"use client";
import { useState } from "react";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";
import { Camera } from "lucide-react";

// Shrinks big phone photos to max 1600px JPEG so uploads are fast and under the 5 MB limit
async function shrink(file: File): Promise<Blob> {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error("Could not read this photo."))), "image/jpeg", 0.85));
}

export default function SnapSolve() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [note, setNote] = useState("");
  const [out, setOut] = useState("");
  const [chatId, setChatId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  function pick(f?: File) {
    if (!f) return;
    setFile(f); setOut(""); setErr(""); setChatId(null);
    setPreview(URL.createObjectURL(f));
  }

  async function solve() {
    if (!file || busy) return;
    setBusy(true); setErr(""); setOut("");
    try {
      const fd = new FormData();
      fd.append("image", await shrink(file), "question.jpg");
      fd.append("note", note);
      const res = await fetch("/api/snap", { method: "POST", body: fd });
      if (!res.ok || !res.body) throw new Error((await res.json().catch(() => null))?.error || "Something went wrong.");
      setChatId(res.headers.get("x-chat-id"));
      const reader = res.body.getReader(); const dec = new TextDecoder(); let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true }); setOut(acc);
      }
    } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong."); }
    finally { setBusy(false); }
  }

  const m = out.match(/^TAG:\s*(.*)\n?/);
  const tag = m?.[1]; const body = m ? out.slice(m[0].length) : out;

  return (
    <div className="space-y-5">
      <label className="flex cursor-pointer flex-col items-center gap-2 rounded-3xl border-2 border-dashed border-ink/25 bg-white p-6 text-center dark:bg-nightcard">
        {preview ? <img src={preview} alt="Your question" className="max-h-64 rounded-xl" /> : <Camera className="h-10 w-10 text-leaf" />}
        <span className="font-medium">{preview ? "Choose a different photo" : "Take a photo or upload one"}</span>
        <span className="text-sm opacity-60">Printed, handwritten, or a book page</span>
        <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} />
      </label>
      <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} maxLength={500} placeholder="Optional: tell me which question, or what you are stuck on"
        className="w-full rounded-2xl border border-ink/20 bg-transparent px-4 py-3" />
      <button onClick={solve} disabled={!file || busy} className="w-full rounded-xl bg-saffron px-4 py-3 font-semibold text-ink disabled:opacity-50">{busy ? "Reading your photo..." : "Solve it"}</button>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
      {out && (
        <div className="rounded-3xl bg-white p-5 dark:bg-nightcard">
          {tag && <p className="mb-3 inline-block rounded-full bg-leaf/15 px-3 py-1 text-sm font-semibold text-leaf">{tag}</p>}
          <div className="md"><ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>{body}</ReactMarkdown></div>
          {chatId && !busy && <Link href={`/tutor?chat=${chatId}`} className="mt-4 inline-block font-medium text-leaf underline">Ask follow-up questions in the tutor</Link>}
        </div>
      )}
      <p className="text-center text-xs opacity-60">AI can misread handwriting. Check the transcribed question first, and verify Acts and sections with official sources.</p>
    </div>
  );
}
