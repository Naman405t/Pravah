"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, Bookmark, BookOpen, Layers, Newspaper, CalendarDays, Camera, ClipboardCheck, Home, MessageCircle, User } from "lucide-react";
import { BRAND } from "@/lib/brand";
import ThemeToggle from "./ThemeToggle";

const ITEMS: { href: string; label: string; Icon: typeof Home; desktop?: boolean }[] = [
  { href: "/home", label: "Home", Icon: Home },
  { href: "/tutor", label: "Tutor", Icon: MessageCircle },
  { href: "/snap", label: "Snap", Icon: Camera, desktop: true },
  { href: "/syllabus", label: "Syllabus", Icon: BookOpen, desktop: true },
  { href: "/current-affairs", label: "Current affairs", Icon: Newspaper, desktop: true },
  { href: "/flashcards", label: "Flashcards", Icon: Layers, desktop: true },
  { href: "/bookmarks", label: "Bookmarks", Icon: Bookmark, desktop: true },
  { href: "/practice", label: "Practice", Icon: ClipboardCheck },
  { href: "/progress", label: "Progress", Icon: BarChart3, desktop: true },
  { href: "/plan", label: "Plan", Icon: CalendarDays },
  { href: "/profile", label: "Profile", Icon: User },
];

const HI: Record<string, string> = { Home: "होम", Tutor: "ट्यूटर", Snap: "फोटो हल", Syllabus: "पाठ्यक्रम", Practice: "अभ्यास", Progress: "प्रगति", Plan: "योजना", Profile: "प्रोफ़ाइल", "Current affairs": "करेंट अफेयर्स", Flashcards: "फ़्लैशकार्ड", Bookmarks: "बुकमार्क" };

export default function Nav({ lang = "en" }: { lang?: string }) {
  const path = usePathname();
  const active = (h: string) => path.startsWith(h);
  return (
    <>
      <aside className="fixed inset-y-0 left-0 hidden w-60 flex-col border-r border-ink/10 bg-white p-5 dark:border-white/10 dark:bg-nightcard md:flex">
        <div className="mb-8 flex items-center justify-between">
          <span className="font-display text-2xl font-bold">{BRAND}</span><ThemeToggle />
        </div>
        <nav className="flex flex-col gap-1">
          {ITEMS.map(({ href, label, Icon }) => (
            <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 font-medium ${active(href) ? "bg-ink text-white dark:bg-leaf" : "hover:bg-ink/5 dark:hover:bg-white/10"}`}>
              <Icon className="h-5 w-5" />{lang === "hi" ? HI[label] ?? label : label}
            </Link>
          ))}
        </nav>
      </aside>
      <nav className="fixed inset-x-0 bottom-0 z-10 flex justify-around border-t border-ink/10 bg-white py-2 dark:border-white/10 dark:bg-nightcard md:hidden">
        {ITEMS.filter((i) => !i.desktop).map(({ href, label, Icon }) => (
          <Link key={href} href={href} className={`flex flex-col items-center gap-0.5 px-3 py-1 text-xs font-medium ${active(href) ? "text-leaf" : "opacity-70"}`}>
            <Icon className="h-5 w-5" />{lang === "hi" ? HI[label] ?? label : label}
          </Link>
        ))}
      </nav>
    </>
  );
}
