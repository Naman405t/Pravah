"use client";
import { Moon, Sun } from "lucide-react";

export default function ThemeToggle() {
  const toggle = () => {
    const dark = document.documentElement.classList.toggle("dark");
    try { localStorage.theme = dark ? "dark" : "light"; } catch {}
  };
  return (
    <button onClick={toggle} aria-label="Toggle dark mode" className="rounded-full p-2 hover:bg-ink/10 dark:hover:bg-white/10">
      <Moon className="h-5 w-5 dark:hidden" /><Sun className="hidden h-5 w-5 dark:block" />
    </button>
  );
}
