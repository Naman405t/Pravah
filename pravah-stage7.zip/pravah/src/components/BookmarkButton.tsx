"use client";
import { useState } from "react";
import { Bookmark } from "lucide-react";

export default function BookmarkButton({ questionId, initial = false }: { questionId: string; initial?: boolean }) {
  const [saved, setSaved] = useState(initial);
  async function toggle() {
    const want = !saved; setSaved(want);
    const r = await fetch("/api/bookmarks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ questionId, saved: want }) }).catch(() => null);
    if (!r?.ok) setSaved(!want);
  }
  return <button onClick={toggle} className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-leaf"><Bookmark className={`h-4 w-4 ${saved ? "fill-current" : ""}`} />{saved ? "Saved" : "Save question"}</button>;
}
