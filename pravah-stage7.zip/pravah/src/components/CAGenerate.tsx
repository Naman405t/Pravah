"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CAGenerate() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  async function go() {
    setBusy(true); setErr("");
    const r = await fetch("/api/current-affairs", { method: "POST" }).catch(() => null);
    const j = await r?.json().catch(() => ({}));
    if (r?.ok) return router.refresh();
    setErr(j?.error || "Network problem. Please retry."); setBusy(false);
  }
  return (
    <div>
      <button onClick={go} disabled={busy} className="rounded-xl bg-saffron px-4 py-2.5 font-semibold text-ink disabled:opacity-60">{busy ? "Searching the news, this can take a minute..." : "Create this week's summary"}</button>
      {err && <p role="alert" className="mt-2 text-sm text-red-600">{err}</p>}
    </div>
  );
}
