"use client";
import { useEffect, useRef, useState } from "react";
import { MARK_CORRECT, NEGATIVE, score } from "@/lib/exam";
import Options from "./Options";
import BookmarkButton from "./BookmarkButton";

type Q = { id: string; stem: string; options: string[] };
type R = { questionId: string; chosen: number | null; correct: boolean; answer: number; explanation: string };

export default function MockRunner({ mockId, questions, minutes }: { mockId: string; questions: Q[]; minutes: number }) {
  const [cur, setCur] = useState(0);
  const [ans, setAns] = useState<Record<string, number>>({});
  const [left, setLeft] = useState(minutes * 60);
  const [results, setResults] = useState<R[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const spent = useRef<Record<string, number>>({});
  const since = useRef(Date.now());
  const submitRef = useRef<() => void>(() => {});

  const leave = () => { const id = questions[cur].id; spent.current[id] = (spent.current[id] ?? 0) + (Date.now() - since.current) / 1000; since.current = Date.now(); };
  const go = (n: number) => { leave(); setCur(n); };

  submitRef.current = async () => {
    if (busy || results) return;
    leave(); setBusy(true); setErr("");
    try {
      const r = await fetch("/api/attempts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
        mockId, attempts: questions.map((q) => ({ questionId: q.id, chosen: ans[q.id] ?? null, seconds: spent.current[q.id] ?? 0 })) }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Could not submit.");
      setResults(j.results);
    } catch (e) { setErr(e instanceof Error ? e.message : "Could not submit. Try again."); }
    setBusy(false);
  };

  useEffect(() => {
    if (results) return;
    const t = setInterval(() => setLeft((l) => { if (l <= 1) { clearInterval(t); setTimeout(() => submitRef.current(), 0); return 0; } return l - 1; }), 1000);
    return () => clearInterval(t);
  }, [results]);

  if (results) {
    const c = results.filter((r) => r.correct).length;
    const un = results.filter((r) => r.chosen === null).length;
    return (
      <div className="space-y-5">
        <div className="rounded-3xl bg-white p-6 dark:bg-nightcard">
          <h2 className="font-display text-3xl font-bold">Score: {score(c, results.length - c - un)}</h2>
          <p className="mt-1">{c} correct, {results.length - c - un} wrong, {un} unattempted. Marking: +{MARK_CORRECT} / -{NEGATIVE.toFixed(2)}.</p>
        </div>
        {questions.map((q, n) => { const r = results.find((x) => x.questionId === q.id)!; return (
          <div key={q.id} className="rounded-3xl bg-white p-5 dark:bg-nightcard">
            <p className="mb-2 text-sm opacity-60">Question {n + 1}{r.chosen === null ? " (not attempted)" : ""}</p>
            <Options stem={q.stem} options={q.options} chosen={r.chosen} onChoose={() => {}} locked answer={r.answer} />
            <p className="mt-3 rounded-xl bg-ink/5 p-3 text-sm dark:bg-white/10">{r.explanation}</p>
            <BookmarkButton questionId={q.id} />
          </div>); })}
      </div>
    );
  }

  const q = questions[cur];
  const mm = String(Math.floor(left / 60)).padStart(2, "0"), ss = String(left % 60).padStart(2, "0");
  return (
    <div className="space-y-4">
      <div className="sticky top-0 z-10 flex items-center justify-between rounded-2xl bg-white px-4 py-2 dark:bg-nightcard">
        <span className="font-semibold">Question {cur + 1} / {questions.length}</span>
        <span className={`font-mono text-lg ${left < 300 ? "text-red-600" : ""}`} aria-live="off">{mm}:{ss}</span>
      </div>
      <div className="rounded-3xl bg-white p-5 dark:bg-nightcard">
        <Options stem={q.stem} options={q.options} chosen={ans[q.id] ?? null} onChoose={(i) => setAns({ ...ans, [q.id]: i })} />
        {ans[q.id] !== undefined && <button onClick={() => { const { [q.id]: _, ...rest } = ans; setAns(rest); }} className="mt-3 text-sm underline">Clear answer</button>}
      </div>
      <div className="flex gap-3">
        <button disabled={cur === 0} onClick={() => go(cur - 1)} className="flex-1 rounded-xl border border-ink/20 px-4 py-2.5 font-medium disabled:opacity-40">Previous</button>
        <button disabled={cur === questions.length - 1} onClick={() => go(cur + 1)} className="flex-1 rounded-xl bg-ink px-4 py-2.5 font-medium text-white disabled:opacity-40 dark:bg-leaf">Next</button>
      </div>
      <div className="flex flex-wrap gap-1.5" aria-label="Question palette">
        {questions.map((x, n) => <button key={x.id} onClick={() => go(n)} aria-label={`Go to question ${n + 1}`}
          className={`h-8 w-8 rounded-lg text-xs font-semibold ${n === cur ? "ring-2 ring-saffron" : ""} ${ans[x.id] !== undefined ? "bg-leaf text-white" : "bg-ink/10 dark:bg-white/10"}`}>{n + 1}</button>)}
      </div>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
      <button disabled={busy} onClick={() => { if (confirm(`Submit now? You answered ${Object.keys(ans).length} of ${questions.length}.`)) submitRef.current(); }}
        className="w-full rounded-xl bg-saffron px-4 py-3 font-semibold text-ink disabled:opacity-50">{busy ? "Submitting..." : "Submit test"}</button>
    </div>
  );
}
