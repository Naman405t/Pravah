"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { MOCKS } from "@/lib/exam";

export default function MockCreate() {
  const router = useRouter();
  const [busy, setBusy] = useState("");
  const [err, setErr] = useState("");
  async function make(kind: string) {
    setBusy(kind); setErr("");
    const r = await fetch("/api/mock/create", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind }) }).catch(() => null);
    const j = await r?.json().catch(() => ({}));
    if (r?.ok) return router.push(`/practice/mock/${j.id}`);
    setErr(j?.error || "Network problem. Please retry."); setBusy("");
  }
  return (
    <div className="space-y-3">
      {Object.entries(MOCKS).map(([k, m]) => (
        <button key={k} disabled={!!busy} onClick={() => make(k)} className="block w-full rounded-2xl bg-white p-5 text-left dark:bg-nightcard disabled:opacity-60">
          <span className="font-display text-xl font-semibold">{m.label}</span>
          <span className="block opacity-70">{m.questions} questions across all 16 subjects, {m.minutes} minutes{busy === k ? ". Building your paper, this can take up to a minute..." : ""}</span>
        </button>
      ))}
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
      <p className="text-xs opacity-60">Question counts and timing are set in src/lib/exam.ts. Match them to the latest official notification.</p>
    </div>
  );
}
