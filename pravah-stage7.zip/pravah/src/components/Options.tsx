const L = ["A", "B", "C", "D"];
export default function Options({ stem, options, chosen, onChoose, locked, answer }: {
  stem: string; options: string[]; chosen: number | null; onChoose: (i: number) => void; locked?: boolean; answer?: number;
}) {
  return (
    <div>
      <p className="mb-4 text-lg font-medium">{stem}</p>
      <div className="space-y-2">
        {options.map((o, i) => {
          let cls = chosen === i ? "border-ink bg-ink/10 dark:border-leaf dark:bg-leaf/20" : "border-ink/20";
          if (answer !== undefined) cls = i === answer ? "border-leaf bg-leaf/15" : chosen === i ? "border-red-500 bg-red-500/10" : "border-ink/10 opacity-70";
          return (
            <button key={i} disabled={locked} onClick={() => onChoose(i)} className={`flex w-full gap-3 rounded-2xl border px-4 py-3 text-left ${cls}`}>
              <b>{L[i]}</b><span>{o}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
