"use client";
import { useRef, useState } from "react";
import Link from "next/link";
import { SUBJECTS } from "@/lib/syllabus";
import { TREE, findTopic } from "@/lib/topics";
import { MARK_CORRECT, NEGATIVE, score } from "@/lib/exam";
import Options from "./Options";
import BookmarkButton from "./BookmarkButton";

type Q = { id: string; stem: string; options: string[] };
type R = { questionId: string; chosen: number | null; correct: boolean; answer: number; explanation: string };

export default function TopicPractice({ initialTopic }: { initialTopic?: string }) {
  const init = findTopic(initialTopic ?? "");
  const [sid, setSid] = useState(init?.subject.id ?? "labour");
  const [tid, setTid] = useState(init?.topic.id ?? TREE.labour[0].id);
  const [diff, setDiff] = useState("medium");
  const [count, setCount] = useState(5);
  const [qs, setQs] = useState<Q[] | null>(null);
  const [i, setI] = useState(0);
  const [sel, setSel] = useState<number | null>(null);
  const [res, setRes] = useState<R | null>(null);
  const [all, setAll] = useState<R[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const t0 = useRef(0);
  const field = "w-full rounded-xl border border-ink/20 bg-transparent px-3 py-2.5";

  async function post(url: string, body: object) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Something went wrong.");
    return j;
  }
  async function start() {
    setBusy(true); setErr("");
    try {
      const j = await post("/api/practice/start", { topicId: tid, difficulty: diff, count });
      setQs(j.questions); setI(0); setAll([]); setSel(null); setRes(null); t0.current = Date.now();
    } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong."); }
    setBusy(false);
  }
  async function check() {
    if (sel === null || !qs) return;
    setBusy(true);
    try {
      const j = await post("/api/attempts", { attempts: [{ questionId: qs[i].id, chosen: sel, seconds: (Date.now() - t0.current) / 1000 }] });
      setRes(j.results[0]); setAll((a) => [...a, j.results[0]]);
    } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong."); }
    setBusy(false);
  }
  const next = () => { setI(i + 1); setSel(null); setRes(null); t0.current = Date.now(); };

  if (!qs) return (
    <div className="space-y-4">
      <label className="block text-sm">Subject<select className={field} value={sid} onChange={(e) => { setSid(e.target.value); setTid(TREE[e.target.value][0].id); }}>
        {SUBJECTS.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
      <label className="block text-sm">Topic<select className={field} value={tid} onChange={(e) => setTid(e.target.value)}>
        {TREE[sid].map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
      <div className="grid grid-cols-2 gap-3">
        <label className="block text-sm">Difficulty<select className={field} value={diff} onChange={(e) => setDiff(e.target.value)}><option>easy</option><option>medium</option><option>hard</option></select></label>
        <label className="block text-sm">Questions<select className={field} value={count} onChange={(e) => setCount(Number(e.target.value))}><option value={5}>5</option><option value={10}>10</option></select></label>
      </div>
      <button onClick={start} disabled={busy} className="w-full rounded-xl bg-saffron px-4 py-3 font-semibold text-ink disabled:opacity-50">{busy ? "Preparing questions..." : "Start practice"}</button>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
      <p className="text-xs opacity-60">New topics can take up to 30 seconds the first time. Marking: +{MARK_CORRECT} per correct answer, -{NEGATIVE.toFixed(2)} per wrong answer. AI questions can contain errors, so cross-check surprising answers.</p>
    </div>
  );

  if (i >= qs.length) {
    const c = all.filter((r) => r.correct).length;
    return (
      <div className="space-y-4 rounded-3xl bg-white p-6 dark:bg-nightcard">
        <h2 className="font-display text-2xl font-bold">Score: {score(c, all.length - c)}</h2>
        <p>{c} correct, {all.length - c} wrong out of {all.length}.</p>
        <button onClick={() => setQs(null)} className="rounded-xl bg-ink px-4 py-2 font-medium text-white dark:bg-leaf">Practice again</button>
        <Link href="/syllabus" className="ml-3 underline">Back to syllabus</Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-sm opacity-70">Question {i + 1} of {qs.length}</p>
      <div className="rounded-3xl bg-white p-5 dark:bg-nightcard">
        <Options stem={qs[i].stem} options={qs[i].options} chosen={res ? res.chosen : sel} onChoose={setSel} locked={!!res} answer={res?.answer} />
        {res && <p className="mt-4 rounded-xl bg-ink/5 p-3 text-sm dark:bg-white/10"><b>{res.correct ? "Correct. " : "Not quite. "}</b>{res.explanation}</p>}
        {res && <BookmarkButton questionId={qs[i].id} />}
      </div>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
      {res ? <button onClick={next} className="w-full rounded-xl bg-ink px-4 py-3 font-semibold text-white dark:bg-leaf">{i + 1 === qs.length ? "See score" : "Next question"}</button>
        : <button onClick={check} disabled={sel === null || busy} className="w-full rounded-xl bg-saffron px-4 py-3 font-semibold text-ink disabled:opacity-50">Check answer</button>}
    </div>
  );
}
