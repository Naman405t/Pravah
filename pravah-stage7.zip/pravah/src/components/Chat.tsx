"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";
import { Send } from "lucide-react";
import FlashButton from "./FlashButton";

type Msg = { role: string; content: string };
const MODES = [
  { id: "solver", label: "Solver", hint: "Step-by-step answers" },
  { id: "socratic", label: "Socratic", hint: "Guides you with questions" },
  { id: "exam", label: "Exam", hint: "Short, UPSC-style, MCQ tricks" },
];
const STARTERS = [
  "Explain the difference between EPF and EPS with section references",
  "Solve: A can do a job in 12 days and B in 18 days. How long together?",
  "Which Article deals with the President's rule in a state?",
];

export default function Chat({ chatId, chats, initial, fixedMode, basePath = "/tutor" }: { chatId: string | null; chats: { id: string; title: string }[]; initial: Msg[]; fixedMode?: string; basePath?: string }) {
  const starters = fixedMode === "interview" ? ["I am ready. Please begin the mock interview."] : STARTERS;
  const router = useRouter();
  const [msgs, setMsgs] = useState<Msg[]>(initial);
  const [mode, setMode] = useState(fixedMode ?? "solver");
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [msgs]);

  async function send(text = input) {
    text = text.trim();
    if (!text || busy) return;
    setInput(""); setBusy(true);
    setMsgs((m) => [...m, { role: "user", content: text }, { role: "assistant", content: "" }]);
    const setLast = (content: string) => setMsgs((m) => [...m.slice(0, -1), { role: "assistant", content }]);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chatId, mode, message: text }) });
      if (!res.ok || !res.body) throw new Error((await res.json().catch(() => null))?.error || "Something went wrong.");
      const newId = res.headers.get("x-chat-id");
      const reader = res.body.getReader(); const dec = new TextDecoder(); let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true }); setLast(acc);
      }
      if (!chatId && newId) router.replace(`${basePath}?chat=${newId}`);
    } catch (e) {
      setLast(`Error: ${e instanceof Error ? e.message : "Something went wrong."}`);
    } finally { setBusy(false); }
  }

  return (
    <div className="flex h-[calc(100dvh-9rem)] flex-col md:h-[calc(100dvh-5rem)]">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div role="radiogroup" className={`${fixedMode ? "hidden" : "flex"} rounded-full bg-ink/10 p-1 dark:bg-white/10`}>
          {MODES.map((m) => (
            <button key={m.id} role="radio" aria-checked={mode === m.id} title={m.hint} onClick={() => setMode(m.id)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium ${mode === m.id ? "bg-ink text-white dark:bg-leaf" : ""}`}>{m.label}</button>
          ))}
        </div>
        <details className="relative ml-auto">
          <summary className="cursor-pointer text-sm font-medium text-leaf">History</summary>
          <div className="absolute right-0 z-10 mt-2 max-h-72 w-64 overflow-y-auto rounded-2xl bg-white p-2 shadow-lg dark:bg-nightcard">
            <Link href={basePath} className="block rounded-lg px-3 py-2 text-sm font-semibold hover:bg-ink/5">New chat</Link>
            {chats.map((c) => <Link key={c.id} href={`${basePath}?chat=${c.id}`} className="block truncate rounded-lg px-3 py-2 text-sm hover:bg-ink/5">{c.title}</Link>)}
          </div>
        </details>
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto pr-1">
        {msgs.length === 0 && (
          <div className="space-y-2 pt-6">
            <p className="font-display text-xl font-semibold">{fixedMode === "interview" ? "Mock personality test" : "Ask any APFC syllabus doubt"}</p>
            {starters.map((s) => <button key={s} onClick={() => send(s)} className="block w-full rounded-2xl border border-ink/15 px-4 py-3 text-left text-sm hover:bg-ink/5">{s}</button>)}
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={m.role === "user" ? "ml-auto max-w-[85%] rounded-2xl bg-ink px-4 py-2.5 text-white dark:bg-leaf" : "max-w-full rounded-2xl bg-white px-4 py-3 dark:bg-nightcard"}>
            {m.role === "user" ? m.content : m.content ? (
              <><div className="md"><ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>{m.content}</ReactMarkdown></div>{!busy && <FlashButton text={m.content} />}</>
            ) : <span className="opacity-60">Thinking...</span>}
          </div>
        ))}
        <div ref={end} />
      </div>

      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="mt-3 flex items-end gap-2">
        <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={2} placeholder="Type your question..."
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          className="flex-1 resize-none rounded-2xl border border-ink/20 bg-transparent px-4 py-3" />
        <button disabled={busy || !input.trim()} aria-label="Send" className="rounded-full bg-saffron p-3 text-ink disabled:opacity-50"><Send className="h-5 w-5" /></button>
      </form>
      <p className="mt-1 text-center text-xs opacity-60">AI can make mistakes. Verify Acts, sections and current affairs with official sources.</p>
    </div>
  );
}
