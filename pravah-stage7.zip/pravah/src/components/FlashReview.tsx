"use client";
import { useState } from "react";

export default function FlashReview({ cards }: { cards: { id: string; front: string; back: string }[] }) {
  const [i, setI] = useState(0);
  const [show, setShow] = useState(false);
  if (i >= cards.length) return <p className="font-medium">All done for now. Cards you missed come back in 10 minutes, the rest on a growing schedule.</p>;
  const c = cards[i];
  const rate = (good: boolean) => { fetch("/api/flashcards/review", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: c.id, good }) }); setI(i + 1); setShow(false); };
  return (
    <div className="space-y-4">
      <p className="text-sm opacity-70">Card {i + 1} of {cards.length}</p>
      <button onClick={() => setShow(true)} className="min-h-40 w-full rounded-3xl bg-white p-6 text-left text-lg dark:bg-nightcard">
        <span className="font-medium">{c.front}</span>
        {show ? <span className="mt-4 block border-t border-ink/10 pt-4 text-leaf dark:border-white/10">{c.back}</span> : <span className="mt-4 block text-sm opacity-60">Tap to show the answer</span>}
      </button>
      {show && <div className="flex gap-3">
        <button onClick={() => rate(false)} className="flex-1 rounded-xl border border-ink/20 px-4 py-3 font-medium">Missed it</button>
        <button onClick={() => rate(true)} className="flex-1 rounded-xl bg-leaf px-4 py-3 font-semibold text-white">Got it</button></div>}
    </div>
  );
}
