"use client";
import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import FlashButton from "./FlashButton";
import remarkGfm from "remark-gfm";

export default function Notes({ topicId }: { topicId: string }) {
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const [tries, setTries] = useState(0);
  useEffect(() => {
    let live = true;
    setErr(""); setText("");
    fetch(`/api/notes?topic=${topicId}`).then(async (r) => {
      const j = await r.json();
      if (!live) return;
      r.ok ? setText(j.content) : setErr(j.error || "Something went wrong.");
    }).catch(() => live && setErr("Network problem. Please retry."));
    return () => { live = false; };
  }, [topicId, tries]);

  if (err) return <div role="alert" className="text-red-600">{err} <button onClick={() => setTries(tries + 1)} className="underline">Retry</button></div>;
  if (!text) return <p className="opacity-70">Preparing notes. The first time a topic is opened this takes about 20 seconds.</p>;
  return (
    <>
      <div className="md"><ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown></div>
      <p className="mt-4 text-xs opacity-60">AI-written notes. Verify Act sections, dates and figures with official sources before relying on them.</p>
      <FlashButton topicId={topicId} />
    </>
  );
}
