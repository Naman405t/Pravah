import Link from "next/link";
import { findTopic } from "@/lib/topics";

export default function RevisionList({ items }: { items: { id: string; reason: string }[] }) {
  if (!items.length) return <p className="opacity-70">Nothing is due. Practise a few topics and your review list will appear here.</p>;
  return (
    <ul className="space-y-3">
      {items.map((d) => { const f = findTopic(d.id); if (!f) return null; return (
        <li key={d.id} className="rounded-2xl border border-ink/10 p-3 dark:border-white/10">
          <p className="font-medium">{f.topic.name} <span className="text-sm font-normal opacity-60">({f.subject.name})</span></p>
          <p className="text-sm opacity-70">{d.reason}</p>
          <div className="mt-2 flex gap-4 text-sm font-medium text-leaf">
            <Link href={`/syllabus/${f.subject.id}/${d.id}`} className="underline">Read notes</Link>
            <Link href={`/practice/topic?topic=${d.id}`} className="underline">Practise</Link>
          </div>
        </li>); })}
    </ul>
  );
}
