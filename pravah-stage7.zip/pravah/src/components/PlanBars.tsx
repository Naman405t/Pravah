import type { PlanItem } from "@/lib/plan";

export default function PlanBars({ plan }: { plan: PlanItem[] }) {
  const max = Math.max(...plan.map((p) => p.hours));
  return (
    <ul className="space-y-3">
      {plan.map((p) => (
        <li key={p.id}>
          <div className="flex justify-between text-sm"><span>{p.name}</span><span className="font-semibold">{p.hours} h/week</span></div>
          <div className="mt-1 h-2 rounded-full bg-ink/10 dark:bg-white/10">
            <div className="h-2 rounded-full bg-leaf" style={{ width: `${(p.hours / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
