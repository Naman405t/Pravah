"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { PLANS } from "@/lib/billing";
import { BRAND } from "@/lib/brand";

declare global { interface Window { Razorpay?: new (o: object) => { open: () => void } } }
const loadScript = () => new Promise<void>((res, rej) => {
  if (window.Razorpay) return res();
  const s = document.createElement("script"); s.src = "https://checkout.razorpay.com/v1/checkout.js";
  s.onload = () => res(); s.onerror = () => rej(new Error("Could not load the payment window.")); document.body.appendChild(s);
});

export default function Checkout() {
  const router = useRouter();
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  async function buy(plan: string) {
    setBusy(true); setMsg("");
    try {
      const r = await fetch("/api/billing/order", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ plan }) });
      const o = await r.json();
      if (!r.ok) throw new Error(o.error);
      await loadScript();
      new window.Razorpay!({
        key: o.keyId, amount: o.amount, currency: "INR", order_id: o.orderId, name: BRAND, description: o.name, theme: { color: "#1B2559" },
        handler: async (p: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => {
          const v = await fetch("/api/billing/verify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orderId: p.razorpay_order_id, paymentId: p.razorpay_payment_id, signature: p.razorpay_signature }) });
          const j = await v.json().catch(() => ({}));
          setMsg(v.ok ? "Payment received. Pro is now active." : `${j.error || "Verification failed."} If money was deducted, contact support with your payment ID ${p.razorpay_payment_id}.`);
          router.refresh();
        },
        modal: { ondismiss: () => setBusy(false) },
      }).open();
    } catch (e) { setMsg(e instanceof Error ? e.message : "Something went wrong."); setBusy(false); }
  }
  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        {PLANS.map((p) => (
          <button key={p.id} disabled={busy} onClick={() => buy(p.id)} className="rounded-2xl bg-ink p-5 text-left text-white disabled:opacity-60 dark:bg-leaf">
            <span className="font-display text-xl font-semibold">{p.name}</span><span className="block text-2xl font-bold">Rs. {p.price}</span><span className="text-sm opacity-80">One payment, no auto-renewal</span>
          </button>))}
      </div>
      {msg && <p role="status" className="text-sm">{msg}</p>}
    </div>
  );
}
