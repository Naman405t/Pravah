"use client";
import { useState } from "react";

export default function FlashButton({ text, topicId }: { text?: string; topicId?: string }) {
  const [state, setState] = useState("");
  async function go() {
    setState("Making cards...");
    const r = await fetch("/api/flashcards/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text, topicId }) }).catch(() => null);
    const j = await r?.json().catch(() => ({}));
    setState(r?.ok ? `Saved ${j.count} flashcards` : j?.error || "Could not make cards.");
  }
  return <button onClick={go} disabled={state === "Making cards..."} className="mt-2 text-sm font-medium text-leaf underline">{state || "Make flashcards"}</button>;
}
